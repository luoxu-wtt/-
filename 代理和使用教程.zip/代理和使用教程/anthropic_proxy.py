﻿"""
Anthropic-to-OpenAI Responses API Protocol Conversion Proxy

Converts Claude Code's Anthropic /v1/messages requests to OpenAI /v1/responses
and streams the response back in Anthropic SSE format.

Protocol mapping:
    Anthropic /v1/messages  <-->  OpenAI /v1/responses
    messages                <-->  input
    system                  <-->  instructions
    max_tokens              <-->  max_output_tokens
    tool_use / tool_result  <-->  function_call / function_call_output

Usage:
    pip install aiohttp
    python anthropic_proxy.py

Then in Claude Code settings (~/.claude/settings.json):
    {
      "env": {
        "ANTHROPIC_BASE_URL": "http://localhost:8082",
        "ANTHROPIC_AUTH_TOKEN": "test11111",
        "ANTHROPIC_CUSTOM_MODEL_OPTION": "gpt-5.3-codex"
      }
    }
"""

import asyncio
import json
import time
import uuid
import logging
from dataclasses import dataclass
from pathlib import Path
from aiohttp import web, ClientSession, TCPConnector
from chat_to_responses_converter import (
    ChatStreamConverter,
    build_chat_completions_response,
    build_openai_request_from_chat,
    convert_chat_messages_to_responses_input,
)
from chat_mode_request_converter import build_openai_chat_mode_request
from proxy_config import (
    UPSTREAM_SESSION_KEY,
    ENABLE_PAYLOAD_SHAPE_LOG,
    MINIMAL_NODE_LOGGING,
    KEY_NODE_LOG_ALLOWLIST,
    UPSTREAM_CONN_LIMIT,
    UPSTREAM_CONN_LIMIT_PER_HOST,
    UPSTREAM_TIMEOUT,
    TARGET_BASE_URL,
    TARGET_PATH,
    TARGET_CHAT_COMPLETIONS_PATH,
    LOCAL_PORT,
    PROTOCOL_MODE,
    CHAT_COMPLETIONS_PROTOCOL,
    MESSAGES_UPSTREAM_MODE,
    TARGET_MESSAGES_PATH,
    MESSAGES_MODEL_OVERRIDE,
    MESSAGES_FORCE_NON_STREAM_RESPONSE,
    STREAM_WRITE_BATCH_LIMIT,
    ENABLE_REQ_MD_RECORD,
    get_advertised_models,
)


COMPLETION_CHUNK_OBJECT = "chat.completion.chunk"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger("anthropic-proxy")



def _normalize_tool_name(name):
    if name is None:
        return ""
    return str(name).strip()


def _json_preview(payload, max_chars=6000):
    try:
        text = json.dumps(payload, ensure_ascii=False)
    except Exception:
        text = str(payload)
    if len(text) > max_chars:
        return f"{text[:max_chars]}...(truncated)"
    return text


def _payload_shape(payload):
    """Return JSON structure summary without payload values."""
    if isinstance(payload, dict):
        shape = {}
        for k, v in payload.items():
            if isinstance(v, dict):
                shape[k] = {"type": "object", "keys": sorted(v.keys())}
            elif isinstance(v, list):
                item_type = "empty"
                if v:
                    first = v[0]
                    if isinstance(first, dict):
                        item_type = f"object({','.join(sorted(first.keys()))})"
                    else:
                        item_type = type(first).__name__
                shape[k] = {"type": "array", "len": len(v), "item": item_type}
            else:
                shape[k] = {"type": type(v).__name__}
        return shape
    return {"type": type(payload).__name__}


def _safe_payload_log(payload):
    """Log payload structure only to avoid sensitive content leakage."""
    return _json_preview(_payload_shape(payload))


def _log_payload_shape(trace_id, label, payload):
    if ENABLE_PAYLOAD_SHAPE_LOG and logger.isEnabledFor(logging.INFO):
        logger.info("[%s] %s: %s", trace_id, label, _safe_payload_log(payload))


REQ_MD_PATH = Path(__file__).with_name("req.md")
_REQ_MD_PENDING = {}
_REQ_MD_PENDING_MAX_ITEMS = 2000
_REQ_MD_PENDING_MAX_AGE_SEC = 1800


def _cleanup_req_md_pending(now_ts=None):
    """Best-effort cleanup for pending request snapshots."""
    if not _REQ_MD_PENDING:
        return

    current = now_ts or time.time()
    expired = [
        tid
        for tid, rec in _REQ_MD_PENDING.items()
        if current - float(rec.get("epoch", current)) > _REQ_MD_PENDING_MAX_AGE_SEC
    ]
    for tid in expired:
        _REQ_MD_PENDING.pop(tid, None)

    if len(_REQ_MD_PENDING) <= _REQ_MD_PENDING_MAX_ITEMS:
        return

    # Trim oldest records if queue grows abnormally.
    sorted_items = sorted(_REQ_MD_PENDING.items(), key=lambda item: float(item[1].get("epoch", 0.0)))
    overflow = len(_REQ_MD_PENDING) - _REQ_MD_PENDING_MAX_ITEMS
    for tid, _ in sorted_items[:overflow]:
        _REQ_MD_PENDING.pop(tid, None)


def _record_messages_request_shapes_to_md(trace_id, incoming_request, converted_request):
    """Cache incoming+converted /v1/messages request details by trace_id."""
    if not ENABLE_REQ_MD_RECORD:
        return
    try:
        now_epoch = time.time()
        incoming_shape = _payload_shape(incoming_request)
        converted_shape = _payload_shape(converted_request)
        incoming_content = _json_preview(incoming_request, max_chars=20000)
        converted_content = _json_preview(converted_request, max_chars=20000)
        _REQ_MD_PENDING[trace_id] = {
            "ts": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now_epoch)),
            "epoch": now_epoch,
            "incoming_shape": incoming_shape,
            "incoming_content": incoming_content,
            "converted_shape": converted_shape,
            "converted_content": converted_content,
        }
        _cleanup_req_md_pending(now_ts=now_epoch)
    except Exception as e:
        logger.warning("[%s] failed to cache request shape/content for req.md: %s", trace_id, e)


def _record_messages_response_shapes_to_md(trace_id, upstream_response, converted_response):
    """Append a full single-request block to req.md."""
    if not ENABLE_REQ_MD_RECORD:
        return
    try:
        now_epoch = time.time()
        pending = _REQ_MD_PENDING.pop(trace_id, None) or {}
        ts = pending.get("ts") or time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now_epoch))

        upstream_shape = _payload_shape(upstream_response)
        converted_shape = _payload_shape(converted_response)
        upstream_content = _json_preview(upstream_response, max_chars=20000)
        converted_content = _json_preview(converted_response, max_chars=20000)

        incoming_shape_json = json.dumps(
            pending.get("incoming_shape", {"missing": True}),
            ensure_ascii=False,
            indent=2,
        )
        converted_request_shape_json = json.dumps(
            pending.get("converted_shape", {"missing": True}),
            ensure_ascii=False,
            indent=2,
        )

        lines = [
            f"## {ts} [{trace_id}] /v1/messages",
            "### Incoming Request Shape",
            "```json",
            incoming_shape_json,
            "```",
            "### Incoming Request Content",
            "```json",
            pending.get("incoming_content", "null"),
            "```",
            "### Converted Upstream Request Shape",
            "```json",
            converted_request_shape_json,
            "```",
            "### Converted Upstream Request Content",
            "```json",
            pending.get("converted_content", "null"),
            "```",
            "### Upstream Response Shape",
            "```json",
            json.dumps(upstream_shape, ensure_ascii=False, indent=2),
            "```",
            "### Upstream Response Content",
            "```json",
            upstream_content,
            "```",
            "### Converted Response Shape",
            "```json",
            json.dumps(converted_shape, ensure_ascii=False, indent=2),
            "```",
            "### Converted Response Content",
            "```json",
            converted_content,
            "```",
            "---",
            "",
        ]
        with REQ_MD_PATH.open("a", encoding="utf-8") as f:
            f.write("\n".join(lines))

        _cleanup_req_md_pending(now_ts=now_epoch)
    except Exception as e:
        logger.warning("[%s] failed to write full request block to req.md: %s", trace_id, e)

def _sanitize_upstream_payload(payload):
    """Remove gateway-incompatible fields before forwarding upstream."""
    if not isinstance(payload, dict):
        return payload

    def _sanitize_dict(d, depth=0):
        out = {}
        for key, value in d.items():
            if "." in key:
                continue
            if key == "stream_options":
                continue
            if isinstance(value, dict):
                out[key] = _sanitize_dict(value, depth + 1)
            elif isinstance(value, list):
                out[key] = [_sanitize_dict(v, depth + 1) if isinstance(v, dict) else v for v in value]
            else:
                if key == "pages":
                    if value is None:
                        out[key] = "1"
                    elif isinstance(value, str) and not value.strip():
                        out[key] = "1"
                    else:
                        out[key] = value
                else:
                    out[key] = value
        return out

    sanitized = _sanitize_dict(dict(payload))
    return sanitized



def _unwrap_responses_payload(payload):
    """Return normalized Responses payload object, otherwise None."""
    candidate = payload
    if isinstance(candidate, dict) and isinstance(candidate.get("response"), dict):
        candidate = candidate.get("response")
    if not isinstance(candidate, dict):
        return None
    if candidate.get("object") == "response" or "output" in candidate:
        return candidate
    return None


def _parse_json_payload(payload_text):
    if payload_text == "[DONE]":
        return None
    try:
        return json.loads(payload_text)
    except json.JSONDecodeError:
        return None


class SSEEventParser:
    """Incremental SSE parser that emits complete event/data payloads."""

    def __init__(self):
        self._buffer = ""
        self._event_type = ""
        self._data_lines = []

    def feed_text(self, text_chunk):
        if not text_chunk:
            return []
        self._buffer += text_chunk
        emitted = []
        while "\n" in self._buffer:
            line, self._buffer = self._buffer.split("\n", 1)
            emitted.extend(self._consume_line(line))
        return emitted

    def finalize(self):
        emitted = []
        if self._buffer:
            emitted.extend(self._consume_line(self._buffer))
            self._buffer = ""
        flushed = self._flush_event()
        if flushed is not None:
            emitted.append(flushed)
        return emitted

    def _consume_line(self, line):
        line_stripped = line.strip()
        if not line_stripped:
            flushed = self._flush_event()
            return [flushed] if flushed is not None else []

        if line_stripped.startswith("event:"):
            emitted = []
            flushed = self._flush_event()
            if flushed is not None:
                emitted.append(flushed)
            self._event_type = line_stripped[6:].strip()
            return emitted

        if line_stripped.startswith("data:"):
            payload = line_stripped[5:].strip()
            if self._event_type or self._data_lines:
                self._data_lines.append(payload)
                return []
            return [{"event": "", "data": payload, "from_accumulator": False}]

        if self._event_type or self._data_lines:
            self._data_lines.append(line)
        return []

    def _flush_event(self):
        if not self._data_lines:
            self._event_type = ""
            return None
        event = {
            "event": self._event_type,
            "data": "\n".join(self._data_lines),
            "from_accumulator": True,
        }
        self._event_type = ""
        self._data_lines = []
        return event


def _convert_sse_event_payload(event_payload):
    if not isinstance(event_payload, dict):
        return None
    raw_data = event_payload.get("data", "")
    if not isinstance(raw_data, str) or not raw_data:
        return None
    parsed = _parse_json_payload(raw_data)
    if not isinstance(parsed, dict):
        return None
    evt_type = event_payload.get("event", "")
    return evt_type, parsed


def _extract_json_from_sse_body(raw_body):
    """Extract the most useful JSON payload from an SSE response body."""
    if not isinstance(raw_body, str) or not raw_body:
        return None

    parser = SSEEventParser()
    best_payload = None
    completed_output_items = []

    def _remember_payload(parsed):
        nonlocal best_payload
        if not isinstance(parsed, dict):
            return
        evt_type = parsed.get("type", "")
        if evt_type == "response.output_item.done":
            item = parsed.get("item")
            if isinstance(item, dict):
                completed_output_items.append(dict(item))
        normalized = _unwrap_responses_payload(parsed)
        if normalized is not None:
            if not normalized.get("output") and completed_output_items:
                normalized = dict(normalized)
                normalized["output"] = list(completed_output_items)
            best_payload = normalized
            return
        if best_payload is None:
            best_payload = parsed

    for event_payload in parser.feed_text(raw_body):
        converted = _convert_sse_event_payload(event_payload)
        if converted is None:
            continue
        _, parsed = converted
        _remember_payload(parsed)

    for event_payload in parser.finalize():
        converted = _convert_sse_event_payload(event_payload)
        if converted is None:
            continue
        _, parsed = converted
        _remember_payload(parsed)

    if isinstance(best_payload, dict) and not best_payload.get("output") and completed_output_items:
        best_payload = dict(best_payload)
        best_payload["output"] = list(completed_output_items)
    return best_payload


def _align_upstream_stream_flag(openai_req, upstream_stream):
    """Keep payload stream flag consistent with routing decision."""
    if isinstance(openai_req, dict):
        openai_req["stream"] = bool(upstream_stream)
    return openai_req


async def _read_upstream_json_or_sse(resp, trace_id=None, route=None):
    """Read JSON body, but fallback to parsing SSE body when upstream mislabels mode."""
    try:
        return await resp.json()
    except Exception as json_exc:
        content_type = (resp.headers.get("Content-Type", "") or "").lower()
        if "text/event-stream" not in content_type:
            raise

        raw_body = await resp.text()
        parsed = _extract_json_from_sse_body(raw_body)
        if parsed is None:
            raise json_exc

        if trace_id and route:
            _log_node(
                trace_id,
                route,
                "upstream.response.body.fallback_sse_parsed",
                body_bytes=len(raw_body.encode("utf-8", errors="replace")),
            )
        return parsed



def _get_upstream_session(request: web.Request) -> ClientSession:
    session = request.app.get(UPSTREAM_SESSION_KEY)
    if session is None or session.closed:
        raise RuntimeError("Upstream client session is not ready")
    return session


async def _on_startup(app: web.Application):
    connector = TCPConnector(limit=UPSTREAM_CONN_LIMIT, limit_per_host=UPSTREAM_CONN_LIMIT_PER_HOST)
    app[UPSTREAM_SESSION_KEY] = ClientSession(timeout=UPSTREAM_TIMEOUT, connector=connector)
    logger.info(
        "Upstream session initialized: limit=%d limit_per_host=%d",
        UPSTREAM_CONN_LIMIT,
        UPSTREAM_CONN_LIMIT_PER_HOST,
    )


async def _on_cleanup(app: web.Application):
    session = app.get(UPSTREAM_SESSION_KEY)
    if session and not session.closed:
        await session.close()


def _log_value(value, max_chars=240):
    if isinstance(value, (dict, list, tuple)):
        text = _json_preview(value, max_chars=max_chars)
    else:
        text = str(value)
    text = text.replace("\n", "\\n")
    if len(text) > max_chars:
        return f"{text[:max_chars]}...(truncated)"
    return text


def _log_node(trace_id, route, node, **fields):
    if MINIMAL_NODE_LOGGING and node not in KEY_NODE_LOG_ALLOWLIST:
        return
    details = " ".join(
        f"{key}={_log_value(value)}"
        for key, value in fields.items()
        if value is not None
    )
    if details:
        logger.info("[%s] [%s] node=%s %s", trace_id, route, node, details)
    else:
        logger.info("[%s] [%s] node=%s", trace_id, route, node)


# ========== Request Conversion: Anthropic /v1/messages -> OpenAI /v1/responses ==========


def convert_tools_a2o(anthropic_tools):
    """Convert Anthropic tool definitions to OpenAI Responses API format.

    Anthropic:  {"name": "x", "description": "...", "input_schema": {...}}
    OpenAI:     {"type": "function", "name": "x", "description": "...", "parameters": {...}}
    """
    if not anthropic_tools:
        return None
    openai_tools = []
    filtered_count = 0
    for tool in anthropic_tools:
        if not isinstance(tool, dict):
            filtered_count += 1
            continue
        tool_name = _normalize_tool_name(tool.get("name"))
        if not tool_name:
            filtered_count += 1
            continue
        openai_tools.append({
            "type": "function",
            "name": tool_name,
            "description": tool.get("description", ""),
            "parameters": tool.get("input_schema", {"type": "object", "properties": {}}),
        })
    if filtered_count:
        logger.warning(
            "Filtered %d invalid anthropic tools with empty/missing name",
            filtered_count,
        )
    return openai_tools or None


def convert_messages_to_input(anthropic_messages):
    """Convert Anthropic messages array to OpenAI Responses API input items.

    Key differences:
      - assistant text        -> {"type": "message", "role": "assistant", "content": [...]}
      - assistant tool_use    -> {"type": "function_call", ...}
      - user tool_result      -> {"type": "function_call_output", ...}
      - user text             -> {"role": "user", "content": "..."}
    """
    input_items = []

    for msg in anthropic_messages:
        role = msg.get("role")
        content = msg.get("content")

        if role == "user":
            items = _convert_user_to_input(content)
            if isinstance(items, list):
                input_items.extend(items)
            else:
                input_items.append(items)

        elif role == "assistant":
            items = _convert_assistant_to_input(content)
            if isinstance(items, list):
                input_items.extend(items)
            else:
                input_items.append(items)

    return input_items


def _convert_user_to_input(content):
    """Convert Anthropic user message content to Responses API input items."""
    if isinstance(content, str):
        return {"role": "user", "content": content}

    results = []
    text_parts = []

    for block in content:
        btype = block.get("type")

        if btype == "tool_result":
            tr_content = block.get("content", "")
            if isinstance(tr_content, list):
                tr_content = "\n".join(
                    b.get("text", "") for b in tr_content if b.get("type") == "text"
                )
            results.append({
                "type": "function_call_output",
                "call_id": block.get("tool_use_id", ""),
                "output": str(tr_content) if tr_content else "",
            })

        elif btype == "text":
            text_parts.append(block.get("text", ""))

        elif btype == "image":
            source = block.get("source", {})
            if source.get("type") == "base64":
                media = source.get("media_type", "image/png")
                data = source.get("data", "")
                text_parts.append({
                    "type": "input_image",
                    "image_url": f"data:{media};base64,{data}",
                })

    if text_parts:
        if len(text_parts) == 1 and isinstance(text_parts[0], str):
            results.append({"role": "user", "content": text_parts[0]})
        else:
            formatted = []
            for p in text_parts:
                if isinstance(p, str):
                    formatted.append({"type": "input_text", "text": p})
                else:
                    formatted.append(p)
            results.append({"role": "user", "content": formatted})

    return results if len(results) != 1 else results[0]


def _convert_assistant_to_input(content):
    """Convert Anthropic assistant message content to Responses API input items.

    Text blocks become a message item; tool_use blocks become function_call items.
    """
    if isinstance(content, str):
        return {
            "type": "message",
            "role": "assistant",
            "content": [{"type": "output_text", "text": content}],
        }

    items = []
    text_parts = []

    for block in content:
        btype = block.get("type")

        if btype == "text":
            text_parts.append(block.get("text", ""))

        elif btype == "tool_use":
            if text_parts:
                items.append({
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "\n".join(text_parts)}],
                })
                text_parts = []

            items.append({
                "type": "function_call",
                "id": f"fc_{uuid.uuid4().hex[:24]}",
                "call_id": block.get("id", f"call_{uuid.uuid4().hex[:24]}"),
                "name": block.get("name", ""),
                "arguments": json.dumps(block.get("input", {}), ensure_ascii=False),
            })

    if text_parts:
        items.append({
            "type": "message",
            "role": "assistant",
            "content": [{"type": "output_text", "text": "\n".join(text_parts)}],
        })

    return items if len(items) != 1 else items[0]


def extract_instructions(system):
    """Extract system prompt into the 'instructions' field for Responses API."""
    if not system:
        return None
    if isinstance(system, str):
        return system
    if isinstance(system, list):
        text = "\n".join(
            b.get("text", "") for b in system if b.get("type") == "text"
        )
        return text if text else None
    return None


def build_openai_request(anthropic_req):
    """Build a complete OpenAI Responses API request from an Anthropic Messages request."""
    openai_req = {
        "model": anthropic_req.get("model", ""),
        "input": convert_messages_to_input(anthropic_req.get("messages", [])),
        "stream": anthropic_req.get("stream", False),
    }

    instructions = extract_instructions(anthropic_req.get("system"))
    if instructions:
        openai_req["instructions"] = instructions

    if "max_tokens" in anthropic_req:
        openai_req["max_output_tokens"] = anthropic_req["max_tokens"]
    if "temperature" in anthropic_req:
        openai_req["temperature"] = anthropic_req["temperature"]
    if "top_p" in anthropic_req:
        openai_req["top_p"] = anthropic_req["top_p"]

    tools = convert_tools_a2o(anthropic_req.get("tools"))
    if tools:
        openai_req["tools"] = tools

    return openai_req


# ========== Response Conversion: OpenAI /v1/responses -> Anthropic (Non-streaming) ==========


def build_anthropic_response(openai_resp, model):
    """Convert a non-streaming OpenAI Responses API response to Anthropic Messages format."""
    msg_id = f"msg_{uuid.uuid4().hex[:24]}"
    content_blocks = []
    has_tool_use = False

    for item in openai_resp.get("output", []):
        item_type = item.get("type")

        if item_type == "message":
            for part in item.get("content", []):
                if part.get("type") == "output_text":
                    content_blocks.append({"type": "text", "text": part.get("text", "")})

        elif item_type == "function_call":
            has_tool_use = True
            try:
                tool_input = json.loads(item.get("arguments", "{}"))
            except json.JSONDecodeError:
                tool_input = {}
            content_blocks.append({
                "type": "tool_use",
                "id": item.get("call_id", f"toolu_{uuid.uuid4().hex[:24]}"),
                "name": item.get("name", ""),
                "input": tool_input,
            })

    if not content_blocks:
        content_blocks.append({"type": "text", "text": ""})

    stop_reason = "tool_use" if has_tool_use else "end_turn"
    status = openai_resp.get("status", "completed")
    if status == "incomplete":
        details = openai_resp.get("incomplete_details", {})
        if details.get("reason") == "max_output_tokens":
            stop_reason = "max_tokens"

    usage = openai_resp.get("usage", {})

    return {
        "id": msg_id,
        "type": "message",
        "role": "assistant",
        "content": content_blocks,
        "model": model,
        "stop_reason": stop_reason,
        "stop_sequence": None,
        "usage": {
            "input_tokens": usage.get("input_tokens", 0),
            "output_tokens": usage.get("output_tokens", 0),
        },
    }





# ========== Response Conversion: OpenAI /v1/responses -> Anthropic (Streaming) ==========


class StreamConverter:
    """Stateful converter: OpenAI Responses API streaming events -> Anthropic SSE events.

    OpenAI Responses API event types:
        response.created                       -> message_start
        response.content_part.added            -> content_block_start (text)
        response.output_text.delta             -> content_block_delta (text_delta)
        response.output_text.done              -> content_block_stop
        response.output_item.added (fn_call)   -> content_block_start (tool_use)
        response.function_call_arguments.delta -> content_block_delta (input_json_delta)
        response.function_call_arguments.done  -> content_block_stop
        response.completed                     -> message_delta + message_stop
    """

    def __init__(self, model):
        self.model = model
        self.msg_id = f"msg_{uuid.uuid4().hex[:24]}"
        self.started = False
        self.content_index = 0
        self.has_tool_use = False
        self.input_tokens = 0
        self.output_tokens = 0
        self._block_open = False

    def convert(self, event_type, data):
        """Process one Responses API SSE event, return a list of Anthropic SSE strings."""
        events = []

        if not self.started:
            events.append(self._sse(
                "message_start",
                {
                    "type": "message_start",
                    "message": {
                        "id": self.msg_id,
                        "type": "message",
                        "role": "assistant",
                        "content": [],
                        "model": self.model,
                        "stop_reason": None,
                        "stop_sequence": None,
                        "usage": {"input_tokens": 0, "output_tokens": 0},
                    },
                },
            ))
            events.append(self._sse("ping", {"type": "ping"}))
            self.started = True

        # --- Text content ---
        if event_type == "response.content_part.added":
            part = data.get("part", {})
            if part.get("type") == "output_text":
                events.append(self._sse(
                    "content_block_start",
                    {
                        "type": "content_block_start",
                        "index": self.content_index,
                        "content_block": {"type": "text", "text": ""},
                    },
                ))
                self._block_open = True

        elif event_type == "response.output_text.delta":
            delta_text = data.get("delta", "")
            if delta_text:
                events.append(self._sse(
                    "content_block_delta",
                    {
                        "type": "content_block_delta",
                        "index": self.content_index,
                        "delta": {"type": "text_delta", "text": delta_text},
                    },
                ))

        elif event_type == "response.output_text.done":
            events.append(self._sse(
                "content_block_stop",
                {"type": "content_block_stop", "index": self.content_index},
            ))
            self.content_index += 1
            self._block_open = False

        elif event_type == "response.content_part.done":
            pass

        # --- Function calls (tool_use) ---
        elif event_type == "response.output_item.added":
            item = data.get("item", {})
            if item.get("type") == "function_call":
                self.has_tool_use = True
                call_id = item.get("call_id", f"toolu_{uuid.uuid4().hex[:24]}")
                name = item.get("name", "")
                events.append(self._sse(
                    "content_block_start",
                    {
                        "type": "content_block_start",
                        "index": self.content_index,
                        "content_block": {
                            "type": "tool_use",
                            "id": call_id,
                            "name": name,
                            "input": "",
                        },
                    },
                ))
                self._block_open = True

        elif event_type == "response.function_call_arguments.delta":
            delta = data.get("delta", "")
            if delta:
                events.append(self._sse(
                    "content_block_delta",
                    {
                        "type": "content_block_delta",
                        "index": self.content_index,
                        "delta": {"type": "input_json_delta", "partial_json": delta},
                    },
                ))

        elif event_type == "response.function_call_arguments.done":
            events.append(self._sse(
                "content_block_stop",
                {"type": "content_block_stop", "index": self.content_index},
            ))
            self.content_index += 1
            self._block_open = False

        elif event_type == "response.output_item.done":
            pass

        # --- Completion ---
        elif event_type == "response.completed":
            resp_obj = data.get("response", {})
            usage = resp_obj.get("usage", {})
            self.input_tokens = usage.get("input_tokens", 0)
            self.output_tokens = usage.get("output_tokens", 0)

            stop_reason = "tool_use" if self.has_tool_use else "end_turn"
            status = resp_obj.get("status", "completed")
            if status == "incomplete":
                details = resp_obj.get("incomplete_details", {})
                if details.get("reason") == "max_output_tokens":
                    stop_reason = "max_tokens"

            if self._block_open:
                events.append(self._sse(
                    "content_block_stop",
                    {"type": "content_block_stop", "index": self.content_index},
                ))
                self._block_open = False

            events.append(self._sse(
                "message_delta",
                {
                    "type": "message_delta",
                    "delta": {
                        "stop_reason": stop_reason,
                        "stop_sequence": None,
                    },
                    "usage": {"output_tokens": self.output_tokens},
                },
            ))
            events.append(self._sse("message_stop", {"type": "message_stop"}))

        return events

    @staticmethod
    def _sse(event_type, data):
        return f"event: {event_type}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


async def _write_initial_sse_ping(response: web.StreamResponse):
    """Send an immediate SSE ping so strict clients don't timeout before first token."""
    await response.write(b"event: ping\ndata: {\"type\":\"ping\"}\n\n")


class _StreamEventBatchWriter:
    """Batch SSE event writes to reduce write syscall frequency."""

    def __init__(self, response: web.StreamResponse, batch_limit: int):
        self._response = response
        self._batch_limit = max(1, int(batch_limit))
        self._buffer = []

    async def write(self, event_text: str):
        if not event_text:
            return
        self._buffer.append(event_text)
        if len(self._buffer) >= self._batch_limit:
            await self.flush()

    async def write_many(self, events):
        for event_text in events:
            await self.write(event_text)

    async def flush(self):
        if not self._buffer:
            return
        await self._response.write("".join(self._buffer).encode())
        self._buffer = []



async def _write_simulated_anthropic_stream_from_response(
    request: web.Request,
    anthropic_resp,
):
    """Simulate Anthropic SSE from a complete Anthropic response object."""
    response = web.StreamResponse(
        status=200,
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )
    await response.prepare(request)
    await _write_initial_sse_ping(response)

    message = anthropic_resp if isinstance(anthropic_resp, dict) else {}
    msg_id = message.get("id", f"msg_{uuid.uuid4().hex[:24]}")
    model = message.get("model", "")
    usage = message.get("usage", {}) if isinstance(message.get("usage"), dict) else {}
    content_blocks = message.get("content", []) if isinstance(message.get("content"), list) else []
    stop_reason = message.get("stop_reason", "end_turn")

    start_event = {
        "type": "message_start",
        "message": {
            "id": msg_id,
            "type": "message",
            "role": "assistant",
            "content": [],
            "model": model,
            "stop_reason": None,
            "stop_sequence": None,
            "usage": {
                "input_tokens": usage.get("input_tokens", 0),
                "output_tokens": 0,
            },
        },
    }
    await response.write(f"event: message_start\ndata: {json.dumps(start_event, ensure_ascii=False)}\n\n".encode())
    await response.write(b"event: ping\ndata: {\"type\":\"ping\"}\n\n")

    for idx, block in enumerate(content_blocks):
        if not isinstance(block, dict):
            continue
        block_type = block.get("type")
        if block_type == "text":
            start_payload = {
                "type": "content_block_start",
                "index": idx,
                "content_block": {"type": "text", "text": ""},
            }
            await response.write(
                f"event: content_block_start\ndata: {json.dumps(start_payload, ensure_ascii=False)}\n\n".encode()
            )
            text = block.get("text", "")
            if text:
                delta_payload = {
                    "type": "content_block_delta",
                    "index": idx,
                    "delta": {"type": "text_delta", "text": text},
                }
                await response.write(
                    f"event: content_block_delta\ndata: {json.dumps(delta_payload, ensure_ascii=False)}\n\n".encode()
                )
            await response.write(
                f"event: content_block_stop\ndata: {json.dumps({'type': 'content_block_stop', 'index': idx}, ensure_ascii=False)}\n\n".encode()
            )
        elif block_type == "tool_use":
            start_payload = {
                "type": "content_block_start",
                "index": idx,
                "content_block": {
                    "type": "tool_use",
                    "id": block.get("id", f"toolu_{uuid.uuid4().hex[:24]}"),
                    "name": block.get("name", ""),
                    "input": "",
                },
            }
            await response.write(
                f"event: content_block_start\ndata: {json.dumps(start_payload, ensure_ascii=False)}\n\n".encode()
            )
            partial_json = json.dumps(block.get("input", {}), ensure_ascii=False)
            if partial_json:
                delta_payload = {
                    "type": "content_block_delta",
                    "index": idx,
                    "delta": {"type": "input_json_delta", "partial_json": partial_json},
                }
                await response.write(
                    f"event: content_block_delta\ndata: {json.dumps(delta_payload, ensure_ascii=False)}\n\n".encode()
                )
            await response.write(
                f"event: content_block_stop\ndata: {json.dumps({'type': 'content_block_stop', 'index': idx}, ensure_ascii=False)}\n\n".encode()
            )

    delta_event = {
        "type": "message_delta",
        "delta": {
            "stop_reason": stop_reason,
            "stop_sequence": message.get("stop_sequence"),
        },
        "usage": {"output_tokens": usage.get("output_tokens", 0)},
    }
    await response.write(f"event: message_delta\ndata: {json.dumps(delta_event, ensure_ascii=False)}\n\n".encode())
    await response.write(b"event: message_stop\ndata: {\"type\":\"message_stop\"}\n\n")
    await response.write_eof()
    return response


# ========== HTTP Handler ==========


async def handle_messages(request: web.Request):
    """Main handler: receive Anthropic request, proxy to Responses-compatible upstream endpoint."""
    trace_id = request.headers.get("X-Request-Id") or f"req_{uuid.uuid4().hex[:12]}"
    route = "v1/messages"
    started_at = time.time()

    try:
        anthropic_req = await request.json()
    except Exception:
        _log_node(trace_id, route, "request.parse.failed", error="invalid_json")
        return web.json_response({"error": "Invalid JSON"}, status=400)

    model = anthropic_req.get("model", "") if isinstance(anthropic_req, dict) else ""
    client_wants_stream = bool(isinstance(anthropic_req, dict) and anthropic_req.get("stream", False))
    downstream_stream = client_wants_stream and (not MESSAGES_FORCE_NON_STREAM_RESPONSE)
    is_chat_completions_upstream = PROTOCOL_MODE == "chat"
    upstream_stream = downstream_stream and (not is_chat_completions_upstream)
    ctx = RequestContext(
        trace_id=trace_id,
        route=route,
        started_at=started_at,
        model=model,
        downstream_stream=downstream_stream,
        upstream_stream=upstream_stream,
    )

    openai_req, headers = _prepare_request(request, anthropic_req, ctx)

    try:
        async with _call_upstream(request, openai_req, headers, ctx) as resp:
            _log_node(
                ctx.trace_id,
                ctx.route,
                "upstream.response.headers",
                status=resp.status,
                content_type=resp.headers.get("Content-Type", ""),
            )

            if resp.status != 200:
                body = await resp.text()
                _log_node(
                    ctx.trace_id,
                    ctx.route,
                    "upstream.response.error",
                    status=resp.status,
                    body_preview=body[:500],
                )
                if resp.status == 404 and "DeploymentNotFound" in body:
                    _log_node(
                        ctx.trace_id,
                        ctx.route,
                        "upstream.response.hint",
                        hint="set PROXY_MESSAGES_MODEL_OVERRIDE to your upstream deployment model",
                    )
                error_payload = {"type": "error", "error": {"type": "api_error", "message": body}}
                _record_messages_response_shapes_to_md(
                    ctx.trace_id,
                    {"status": resp.status, "content_type": resp.headers.get("Content-Type", ""), "body_preview": body[:500]},
                    error_payload,
                )
                return _anthropic_error("api_error", body, resp.status)

            if not ctx.downstream_stream or not ctx.upstream_stream:
                return await _handle_non_stream(request, resp, model, ctx, openai_req)
            return await _handle_stream(request, resp, model, ctx, openai_req)

    except asyncio.TimeoutError:
        _log_node(
            ctx.trace_id,
            ctx.route,
            "error.gateway.timeout",
            elapsed_ms=_elapsed_ms(ctx),
        )
        return _anthropic_error("timeout_error", "Gateway timeout", 504)
    except Exception as e:
        _log_node(
            ctx.trace_id,
            ctx.route,
            "error.proxy.exception",
            elapsed_ms=_elapsed_ms(ctx),
            error=str(e),
        )
        logger.error("[%s] <- proxy error: %s", ctx.trace_id, e, exc_info=True)
        return _anthropic_error("api_error", str(e), 502)


def _log_upstream_error(trace_id, evt_type, data):
    resp_obj = data.get("response", {}) if isinstance(data, dict) else {}
    resp_error = resp_obj.get("error") if isinstance(resp_obj, dict) else None
    data_error = data.get("error") if isinstance(data, dict) else None
    error_detail = data_error or resp_error
    if isinstance(error_detail, dict):
        msg = error_detail.get("message", json.dumps(error_detail, ensure_ascii=False)[:500])
    else:
        msg = str(error_detail)[:500] if error_detail else "unknown"
    _log_node(trace_id, "upstream", "event.failed", event_type=evt_type, message=msg)
    logger.error("[%s] <- upstream %s: %s", trace_id, evt_type, msg)


class _SseAccumulator:
    """Helper to accumulate multi-line SSE event+data pairs."""

    def __init__(self, event_type):
        self.__type__ = event_type
        self.__data__ = ""


@dataclass
class RequestContext:
    trace_id: str
    route: str
    started_at: float
    model: str
    downstream_stream: bool
    upstream_stream: bool


def _anthropic_error(error_type, message, status):
    return web.json_response(
        {
            "type": "error",
            "error": {"type": error_type, "message": message},
        },
        status=status,
    )


def _elapsed_ms(ctx: RequestContext):
    return int((time.time() - ctx.started_at) * 1000)


def _log_request_received(ctx: RequestContext, anthropic_req):
    request_messages = anthropic_req.get("messages", []) if isinstance(anthropic_req, dict) else []
    request_tools = anthropic_req.get("tools", []) if isinstance(anthropic_req, dict) else []
    _log_node(
        ctx.trace_id,
        ctx.route,
        "request.received",
        model=ctx.model,
        stream=bool(isinstance(anthropic_req, dict) and anthropic_req.get("stream", False)),
        downstream_stream=ctx.downstream_stream,
        upstream_stream=ctx.upstream_stream,
        messages=len(request_messages) if isinstance(request_messages, list) else 0,
        tools=len(request_tools) if isinstance(request_tools, list) else 0,
    )


def _prepare_request(request: web.Request, anthropic_req, ctx: RequestContext):
    auth = request.headers.get("Authorization", "")
    api_key = request.headers.get("X-Api-Key", "")
    token = api_key or auth.replace("Bearer ", "", 1)

    _log_request_received(ctx, anthropic_req)
    _log_payload_shape(ctx.trace_id, "messages incoming payload shape", anthropic_req)

    openai_req = build_openai_request(anthropic_req)
    openai_req = _align_upstream_stream_flag(openai_req, ctx.upstream_stream)
    openai_req = _sanitize_upstream_payload(openai_req)
    if MESSAGES_MODEL_OVERRIDE:
        original_model = openai_req.get("model", "")
        openai_req["model"] = MESSAGES_MODEL_OVERRIDE
        if original_model != MESSAGES_MODEL_OVERRIDE:
            _log_node(
                ctx.trace_id,
                ctx.route,
                "request.model_overridden",
                from_model=original_model,
                to_model=MESSAGES_MODEL_OVERRIDE,
            )

    converted_input = openai_req.get("input")
    _log_node(
        ctx.trace_id,
        ctx.route,
        "request.converted",
        input_items=len(converted_input) if isinstance(converted_input, list) else 0,
        has_tools="tools" in openai_req,
        has_instructions="instructions" in openai_req,
    )
    _log_payload_shape(ctx.trace_id, "messages outgoing payload shape", openai_req)
    _record_messages_request_shapes_to_md(ctx.trace_id, anthropic_req, openai_req)

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
    }
    return openai_req, headers


def _call_upstream(request: web.Request, openai_req, headers, ctx: RequestContext):
    target_url = f"{TARGET_BASE_URL}{TARGET_MESSAGES_PATH}"
    session = _get_upstream_session(request)
    _log_node(
        ctx.trace_id,
        ctx.route,
        "upstream.request.sending",
        method="POST",
        path=TARGET_MESSAGES_PATH,
        stream=ctx.upstream_stream,
    )
    return session.post(target_url, json=openai_req, headers=headers)


def _prepare_responses_request(request: web.Request, incoming_req, trace_id, route, client_wants_stream):
    auth = request.headers.get("Authorization", "")
    api_key = request.headers.get("X-Api-Key", "")
    token = api_key or auth.replace("Bearer ", "", 1)

    model = incoming_req.get("model", "") if isinstance(incoming_req, dict) else ""
    upstream_req = _normalize_responses_upstream_request(incoming_req, client_wants_stream)

    _log_node(
        trace_id,
        route,
        "request.received",
        model=model,
        stream=client_wants_stream,
        path=TARGET_PATH,
    )
    _log_payload_shape(trace_id, f"{route} incoming payload shape", incoming_req)
    _log_payload_shape(trace_id, f"{route} outgoing payload shape", upstream_req)

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
    }
    return upstream_req, headers, model


def _call_responses_upstream(request: web.Request, upstream_req, headers, trace_id, route, upstream_path, client_wants_stream):
    target_url = f"{TARGET_BASE_URL}{upstream_path}"
    session = _get_upstream_session(request)
    _log_node(trace_id, route, "upstream.request.sending", method="POST", path=upstream_path, stream=client_wants_stream)
    return session.post(target_url, json=upstream_req, headers=headers)


async def _handle_responses_stream_passthrough(request: web.Request, resp, trace_id, route, started_at):
    downstream = web.StreamResponse(
        status=200,
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )
    downstream.headers.update(_build_cors_headers())
    await downstream.prepare(request)
    await _write_initial_sse_ping(downstream)
    _log_node(trace_id, route, "downstream.stream.prepared", mode="upstream_passthrough")
    async for raw_chunk in resp.content:
        await downstream.write(raw_chunk)
    await downstream.write_eof()
    _log_node(
        trace_id,
        route,
        "downstream.stream.completed",
        elapsed_ms=int((time.time() - started_at) * 1000),
    )
    return downstream


async def _handle_responses_non_stream(resp, trace_id, route, model, started_at, upstream_path):
    upstream_body = await _read_upstream_json_or_sse(resp, trace_id=trace_id, route=route)
    responses_payload = _unwrap_responses_payload(upstream_body)
    if responses_payload is None:
        if isinstance(upstream_body, dict):
            responses_payload = upstream_body
        else:
            _log_node(trace_id, route, "upstream.response.invalid_protocol", path=upstream_path)
            return _json_response_with_cors(
                {"error": {"type": "api_error", "message": "upstream response is not valid JSON object"}},
                status=502,
            )

    normalized = _normalize_strict_responses_payload(responses_payload, request_model=model)
    _log_payload_shape(trace_id, f"{route} return payload shape", normalized)
    _log_node(
        trace_id,
        route,
        "downstream.response.sent",
        mode="non_stream",
        elapsed_ms=int((time.time() - started_at) * 1000),
    )
    return _json_response_with_cors(normalized)


async def _handle_non_stream(request: web.Request, resp, model, ctx: RequestContext, converted_request):
    openai_resp = await _read_upstream_json_or_sse(resp, trace_id=ctx.trace_id, route=ctx.route)
    _log_node(ctx.trace_id, ctx.route, "upstream.response.body.received", mode="non_stream")
    _log_payload_shape(ctx.trace_id, "messages upstream payload shape", openai_resp)
    responses_payload = _unwrap_responses_payload(openai_resp)
    if responses_payload is None:
        _log_node(
            ctx.trace_id,
            ctx.route,
            "upstream.response.invalid_protocol",
            protocol_mode=PROTOCOL_MODE,
            path=TARGET_MESSAGES_PATH,
        )
        return _anthropic_error(
            "api_error",
            "upstream response is not Responses format in current protocol mode",
            502,
        )

    anthropic_resp = build_anthropic_response(responses_payload, model)
    _log_payload_shape(ctx.trace_id, "messages return payload shape", anthropic_resp)
    _record_messages_response_shapes_to_md(ctx.trace_id, openai_resp, anthropic_resp)
    if ctx.downstream_stream and not ctx.upstream_stream:
        _log_node(ctx.trace_id, ctx.route, "downstream.stream.simulated")
        return await _write_simulated_anthropic_stream_from_response(request, anthropic_resp)

    _log_node(
        ctx.trace_id,
        ctx.route,
        "downstream.response.sent",
        mode="non_stream",
        input_tokens=anthropic_resp["usage"].get("input_tokens", 0),
        output_tokens=anthropic_resp["usage"].get("output_tokens", 0),
        elapsed_ms=_elapsed_ms(ctx),
    )
    return web.json_response(anthropic_resp)


def _process_stream_event_payload(event_payload, converter, ctx: RequestContext, trailing=False):
    raw_data = event_payload.get("data", "") if isinstance(event_payload, dict) else ""
    if raw_data == "[DONE]":
        return 0, []

    try:
        data = json.loads(raw_data)
    except json.JSONDecodeError:
        if isinstance(event_payload, dict) and event_payload.get("from_accumulator"):
            if trailing:
                _log_node(ctx.trace_id, ctx.route, "upstream.event.trailing_parse.failed")
            else:
                _log_node(
                    ctx.trace_id,
                    ctx.route,
                    "upstream.event.parse.failed",
                    event=event_payload.get("event", ""),
                    data_len=len(raw_data),
                )
        return 0, []

    if not isinstance(data, dict):
        return 0, []

    evt_type = data.get("type", "")
    if isinstance(event_payload, dict):
        evt_type = data.get("type", event_payload.get("event", "") or "")

    if evt_type in ("response.failed", "error"):
        _log_upstream_error(ctx.trace_id, evt_type, data)

    converted = converter.convert(evt_type, data)
    return 1, converted




async def _handle_stream(request: web.Request, resp, model, ctx: RequestContext, converted_request):
    converter = StreamConverter(model)
    parser = SSEEventParser()
    response = web.StreamResponse(
        status=200,
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )
    await response.prepare(request)
    await _write_initial_sse_ping(response)
    _log_node(ctx.trace_id, ctx.route, "downstream.stream.prepared")

    upstream_chunks = 0
    upstream_bytes = 0
    parsed_events = 0
    converted_events = 0
    writer = _StreamEventBatchWriter(response, STREAM_WRITE_BATCH_LIMIT)

    async def _queue_converted_events(converted):
        nonlocal converted_events
        converted_events += len(converted)
        await writer.write_many(converted)

    async for raw_chunk in resp.content:
        upstream_chunks += 1
        upstream_bytes += len(raw_chunk)
        chunk_text = raw_chunk.decode("utf-8", errors="replace")
        for event_payload in parser.feed_text(chunk_text):
            parsed_delta, converted = _process_stream_event_payload(event_payload, converter, ctx)
            parsed_events += parsed_delta
            await _queue_converted_events(converted)

    for event_payload in parser.finalize():
        parsed_delta, converted = _process_stream_event_payload(event_payload, converter, ctx, trailing=True)
        parsed_events += parsed_delta
        await _queue_converted_events(converted)

    if not converter.started:
        converted = converter.convert("response.completed", {"response": {"status": "completed"}})
        await _queue_converted_events(converted)

    await writer.flush()
    _record_messages_response_shapes_to_md(
        ctx.trace_id,
        {
            "stream": True,
            "upstream_chunks": upstream_chunks,
            "upstream_bytes": upstream_bytes,
            "parsed_events": parsed_events,
        },
        {
            "stream": True,
            "converted_events": converted_events,
            "usage": {"input_tokens": converter.input_tokens, "output_tokens": converter.output_tokens},
        },
    )
    await response.write_eof()
    _log_node(
        ctx.trace_id,
        ctx.route,
        "downstream.stream.completed",
        elapsed_ms=_elapsed_ms(ctx),
        upstream_chunks=upstream_chunks,
        upstream_bytes=upstream_bytes,
        parsed_events=parsed_events,
        converted_events=converted_events,
        input_tokens=converter.input_tokens,
        output_tokens=converter.output_tokens,
    )
    return response


def _normalize_responses_upstream_request(incoming_req, client_wants_stream):
    """Prepare upstream /responses request using messages-compatible conversion."""
    if not isinstance(incoming_req, dict):
        return {"stream": bool(client_wants_stream)}

    base_req = dict(incoming_req)

    # If request looks Anthropic-like, reuse the same converter as /v1/messages
    # so messages/system/max_tokens/tools are handled consistently.
    has_anthropic_shape = any(k in base_req for k in ("messages", "system", "max_tokens"))
    if has_anthropic_shape and "input" not in base_req:
        normalized = build_openai_request(base_req)
    else:
        normalized = dict(base_req)

    if "messages" in normalized:
        existing_input = normalized.get("input")
        if existing_input in (None, "", [], {}):
            converted_input = convert_chat_messages_to_responses_input(normalized.get("messages", []))
            if converted_input:
                normalized["input"] = converted_input
        normalized.pop("messages", None)

    if "max_output_tokens" not in normalized:
        if "max_tokens" in normalized:
            normalized["max_output_tokens"] = normalized.get("max_tokens")
        elif "max_completion_tokens" in normalized:
            normalized["max_output_tokens"] = normalized.get("max_completion_tokens")
    normalized.pop("max_tokens", None)
    normalized.pop("max_completion_tokens", None)

    normalized = _sanitize_upstream_payload(normalized)
    if isinstance(normalized, dict):
        normalized["stream"] = bool(client_wants_stream)
    return normalized



def _normalize_strict_responses_payload(upstream_payload, request_model=""):
    """Normalize /responses payload to a stable OpenAI-style shape.

    Keep upstream values when present, and only backfill missing fields so the
    proxy output is predictable for strict clients.
    """
    payload = dict(upstream_payload or {})
    now_ts = int(time.time())

    payload["object"] = "response"

    if not payload.get("id"):
        payload["id"] = f"resp_{uuid.uuid4().hex}"

    created_at = payload.get("created_at")
    if created_at is None:
        created_at = payload.get("created")
    if created_at is None:
        created_at = now_ts
    payload["created_at"] = created_at

    payload.setdefault("status", "completed")
    payload.setdefault("background", False)

    if payload.get("status") == "completed" and payload.get("completed_at") is None:
        payload["completed_at"] = created_at

    payload.setdefault("content_filters", [])
    payload.setdefault("error", None)
    payload.setdefault("frequency_penalty", 0.0)
    payload.setdefault("incomplete_details", None)
    payload.setdefault("instructions", None)
    payload.setdefault("max_output_tokens", None)
    payload.setdefault("max_tool_calls", None)
    payload.setdefault("model", request_model or "")
    payload.setdefault("output", [])
    payload.setdefault("parallel_tool_calls", True)
    payload.setdefault("presence_penalty", 0.0)
    payload.setdefault("previous_response_id", None)
    payload.setdefault("prompt_cache_key", None)
    payload.setdefault("prompt_cache_retention", None)

    reasoning = payload.get("reasoning")
    if not isinstance(reasoning, dict):
        reasoning = {}
    reasoning.setdefault("effort", "medium")
    reasoning.setdefault("summary", None)
    payload["reasoning"] = reasoning

    payload.setdefault("safety_identifier", None)
    payload.setdefault("service_tier", "auto")
    payload.setdefault("store", True)
    payload.setdefault("temperature", 1.0)

    text_cfg = payload.get("text")
    if not isinstance(text_cfg, dict):
        text_cfg = {}
    text_format = text_cfg.get("format")
    if not isinstance(text_format, dict):
        text_format = {}
    text_format.setdefault("type", "text")
    text_cfg["format"] = text_format
    text_cfg.setdefault("verbosity", "medium")
    payload["text"] = text_cfg

    payload.setdefault("tool_choice", "auto")
    payload.setdefault("tools", [])
    payload.setdefault("top_logprobs", 0)
    payload.setdefault("top_p", 0.98)
    payload.setdefault("truncation", "disabled")

    usage = payload.get("usage")
    if not isinstance(usage, dict):
        usage = {}
    usage.setdefault("input_tokens", 0)
    input_tokens_details = usage.get("input_tokens_details")
    if not isinstance(input_tokens_details, dict):
        input_tokens_details = {}
    input_tokens_details.setdefault("cached_tokens", 0)
    usage["input_tokens_details"] = input_tokens_details

    usage.setdefault("output_tokens", 0)
    output_tokens_details = usage.get("output_tokens_details")
    if not isinstance(output_tokens_details, dict):
        output_tokens_details = {}
    output_tokens_details.setdefault("reasoning_tokens", 0)
    usage["output_tokens_details"] = output_tokens_details

    usage.setdefault("total_tokens", usage.get("input_tokens", 0) + usage.get("output_tokens", 0))
    payload["usage"] = usage

    payload.setdefault("user", None)

    metadata = payload.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}
    payload["metadata"] = metadata

    return payload


async def _handle_responses_proxy(request: web.Request, upstream_path: str, route: str):
    trace_id = request.headers.get("X-Request-Id") or f"req_{uuid.uuid4().hex[:12]}"
    started_at = time.time()

    try:
        incoming_req = await request.json()
    except Exception:
        _log_node(trace_id, route, "request.parse.failed", error="invalid_json")
        return _json_response_with_cors({"error": "Invalid JSON"}, status=400)

    client_wants_stream = bool(isinstance(incoming_req, dict) and incoming_req.get("stream", False))
    upstream_req, headers, model = _prepare_responses_request(request, incoming_req, trace_id, route, client_wants_stream)

    try:
        async with _call_responses_upstream(
            request,
            upstream_req,
            headers,
            trace_id,
            route,
            upstream_path,
            client_wants_stream,
        ) as resp:
            _log_node(
                trace_id,
                route,
                "upstream.response.headers",
                status=resp.status,
                content_type=resp.headers.get("Content-Type", ""),
            )

            if resp.status != 200:
                err_body = await resp.text()
                _log_node(trace_id, route, "upstream.response.error", status=resp.status, body_preview=err_body[:500])
                try:
                    return _json_response_with_cors(json.loads(err_body), status=resp.status)
                except Exception:
                    return _json_response_with_cors(
                        {"error": {"type": "api_error", "message": err_body}},
                        status=resp.status,
                    )

            content_type = (resp.headers.get("Content-Type", "") or "").lower()
            if client_wants_stream and "text/event-stream" in content_type:
                return await _handle_responses_stream_passthrough(request, resp, trace_id, route, started_at)

            return await _handle_responses_non_stream(resp, trace_id, route, model, started_at, upstream_path)

    except asyncio.TimeoutError:
        _log_node(trace_id, route, "error.gateway.timeout", elapsed_ms=int((time.time() - started_at) * 1000))
        return _json_response_with_cors(
            {"error": {"type": "timeout_error", "message": "Gateway timeout"}},
            status=504,
        )
    except (ConnectionResetError, BrokenPipeError, asyncio.CancelledError) as e:
        _log_node(trace_id, route, "error.client_disconnected", error=str(e))
        return web.Response(status=499, text="Client Closed Request")
    except Exception as e:
        _log_node(
            trace_id,
            route,
            "error.proxy.exception",
            elapsed_ms=int((time.time() - started_at) * 1000),
            error=str(e),
        )
        logger.error("[%s] <- proxy error: %s", trace_id, e, exc_info=True)
        return _json_response_with_cors(
            {"error": {"type": "api_error", "message": str(e)}},
            status=502,
        )


async def handle_responses(request: web.Request):
    return await _handle_responses_proxy(request, TARGET_PATH, "v1/responses")


def _prepare_chat_standard_request(chat_req, token, trace_id, route):
    model = chat_req.get("model", "")
    client_wants_stream = bool(chat_req.get("stream", False))

    upstream_req = build_openai_chat_mode_request(chat_req)
    upstream_req["stream"] = client_wants_stream

    converted_input = upstream_req.get("input", [])
    _log_node(
        trace_id,
        route,
        "request.converted",
        model=model,
        client_stream=client_wants_stream,
        upstream_stream=client_wants_stream,
        input_items=len(converted_input) if isinstance(converted_input, list) else 0,
        has_tools="tools" in upstream_req,
        outgoing_keys=sorted(upstream_req.keys()) if isinstance(upstream_req, dict) else [],
    )

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
    }
    return model, client_wants_stream, upstream_req, headers


def _call_chat_standard_upstream(request: web.Request, upstream_req, headers, trace_id, route, client_wants_stream):
    target_url = f"{TARGET_BASE_URL}{TARGET_CHAT_COMPLETIONS_PATH}"
    session = _get_upstream_session(request)
    serialized_body = json.dumps(upstream_req, ensure_ascii=False, separators=(",", ":"))
    _log_node(
        trace_id,
        route,
        "upstream.request.sending",
        method="POST",
        path=TARGET_CHAT_COMPLETIONS_PATH,
        stream=client_wants_stream,
        body_bytes=len(serialized_body.encode("utf-8")),
    )
    return session.post(target_url, data=serialized_body.encode("utf-8"), headers=headers)


async def _handle_chat_standard_stream(request: web.Request, resp, model, trace_id, route, started_at):
    converter = ChatStreamConverter(model)
    parser = SSEEventParser()
    response = web.StreamResponse(
        status=200,
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )
    await response.prepare(request)
    await _write_initial_sse_ping(response)
    _log_node(trace_id, route, "downstream.stream.prepared", mode="upstream_passthrough")
    writer = _StreamEventBatchWriter(response, STREAM_WRITE_BATCH_LIMIT)

    async def _queue_converted_events(converted):
        await writer.write_many(converted)

    async for raw_chunk in resp.content:
        chunk_text = raw_chunk.decode("utf-8", errors="replace")
        for event_payload in parser.feed_text(chunk_text):
            parsed_delta, converted = _process_stream_event_payload(
                event_payload,
                converter,
                RequestContext(trace_id, route, started_at, model, True, True),
            )
            _ = parsed_delta
            await _queue_converted_events(converted)

    for event_payload in parser.finalize():
        parsed_delta, converted = _process_stream_event_payload(
            event_payload,
            converter,
            RequestContext(trace_id, route, started_at, model, True, True),
            trailing=True,
        )
        _ = parsed_delta
        await _queue_converted_events(converted)

    if not converter.started or not converter.finished:
        await _queue_converted_events(converter.convert("response.completed", {"response": {"status": "completed"}}))

    await writer.flush()
    await response.write_eof()
    _log_node(
        trace_id,
        route,
        "downstream.stream.completed",
        mode="upstream_passthrough",
        elapsed_ms=int((time.time() - started_at) * 1000),
    )
    return response


async def _handle_chat_standard_non_stream_or_simulated_stream(request: web.Request, resp, chat_req, model, trace_id, route, started_at, client_wants_stream):
    upstream_body = await _read_upstream_json_or_sse(resp, trace_id=trace_id, route=route)
    responses_payload = _unwrap_responses_payload(upstream_body)
    if responses_payload is None:
        _log_node(
            trace_id,
            route,
            "upstream.response.invalid_protocol",
            protocol_mode=PROTOCOL_MODE,
            path=TARGET_CHAT_COMPLETIONS_PATH,
        )
        return web.json_response(
            {"error": {"message": "upstream response is not Responses format in current protocol mode", "type": "api_error"}},
            status=502,
        )

    chat_resp = build_chat_completions_response(responses_payload, model)
    requested_tools_count = len(chat_req.get("tools", []) or [])
    choices = chat_resp.get("choices", []) if isinstance(chat_resp, dict) else []
    message = choices[0].get("message", {}) if choices else {}
    returned_tool_calls = message.get("tool_calls", []) if isinstance(message, dict) else []
    if requested_tools_count > 0 and not returned_tool_calls:
        _log_node(
            trace_id,
            route,
            "upstream.response.hint",
            hint="tools requested but upstream returned no function_call/tool_calls",
            requested_tools=requested_tools_count,
        )

    _log_node(
        trace_id,
        route,
        "upstream.response.received",
        format="responses->chat",
        elapsed_ms=int((time.time() - started_at) * 1000),
    )

    if not client_wants_stream:
        return web.json_response(chat_resp)

    response = web.StreamResponse(
        status=200,
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )
    await response.prepare(request)
    await _write_initial_sse_ping(response)

    chat_id = chat_resp.get("id", f"chatcmpl-{uuid.uuid4().hex}")
    created = chat_resp.get("created", int(time.time()))
    choices = chat_resp.get("choices", [])
    choice = choices[0] if choices else {}
    message = choice.get("message", {})
    finish_reason = choice.get("finish_reason", "stop")

    def _chunk(delta, fr=None):
        payload = {
            "id": chat_id,
            "object": COMPLETION_CHUNK_OBJECT,
            "created": created,
            "model": model,
            "choices": [{"index": 0, "delta": delta, "finish_reason": fr}],
        }
        return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"

    await response.write(_chunk({"role": "assistant"}).encode())
    content = message.get("content")
    if content:
        await response.write(_chunk({"content": content}).encode())
    tool_calls = message.get("tool_calls")
    if tool_calls:
        for idx, tc in enumerate(tool_calls):
            await response.write(_chunk({
                "tool_calls": [{
                    "index": idx,
                    "id": tc.get("id", f"call_{uuid.uuid4().hex[:24]}"),
                    "type": "function",
                    "function": {
                        "name": tc["function"]["name"],
                        "arguments": tc["function"].get("arguments", "{}"),
                    },
                }]
            }).encode())
    await response.write(_chunk({}, fr=finish_reason).encode())
    await response.write(b"data: [DONE]\n\n")
    await response.write_eof()
    _log_node(
        trace_id,
        route,
        "downstream.stream.simulated",
        reason="upstream_non_stream_content_type",
        elapsed_ms=int((time.time() - started_at) * 1000),
    )
    return response


async def _handle_chat_completions_standard(
    request: web.Request,
    chat_req,
    token,
    trace_id,
    started_at,
):
    """Standard mode: Cursor -> upstream /developer/v1/chat/completions (Responses API).

    Cursor already sends Responses-format payloads. We sanitize and forward them.
    When the client requests streaming, prefer true upstream streaming; if the
    upstream still replies as JSON, fallback to simulated SSE for compatibility.
    """
    route = "v1/chat/completions.standard"
    model, client_wants_stream, upstream_req, headers = _prepare_chat_standard_request(chat_req, token, trace_id, route)

    try:
        async with _call_chat_standard_upstream(
            request,
            upstream_req,
            headers,
            trace_id,
            route,
            client_wants_stream,
        ) as resp:
            if resp.status != 200:
                body = await resp.text()
                _log_node(trace_id, route, "upstream.response.error", status=resp.status, body_preview=body[:500])
                return web.json_response(
                    {"error": {"message": body, "type": "api_error"}},
                    status=resp.status,
                )

            content_type = (resp.headers.get("Content-Type", "") or "").lower()
            should_parse_upstream_stream = client_wants_stream and ("text/event-stream" in content_type)
            if should_parse_upstream_stream:
                return await _handle_chat_standard_stream(request, resp, model, trace_id, route, started_at)

            return await _handle_chat_standard_non_stream_or_simulated_stream(
                request,
                resp,
                chat_req,
                model,
                trace_id,
                route,
                started_at,
                client_wants_stream,
            )

    except asyncio.TimeoutError:
        _log_node(trace_id, route, "error.gateway.timeout", elapsed_ms=int((time.time() - started_at) * 1000))
        return web.json_response(
            {"error": {"message": "Gateway timeout", "type": "timeout_error"}},
            status=504,
        )
    except (ConnectionResetError, BrokenPipeError, asyncio.CancelledError) as e:
        _log_node(trace_id, route, "error.client_disconnected", error=str(e))
        return web.Response(status=499, text="Client Closed Request")
    except Exception as e:
        _log_node(
            trace_id,
            route,
            "error.proxy.exception",
            elapsed_ms=int((time.time() - started_at) * 1000),
            error=str(e),
        )
        return web.json_response(
            {"error": {"message": str(e), "type": "api_error"}},
            status=502,
        )


def _prepare_chat_request(request: web.Request, chat_req, trace_id, route):
    auth = request.headers.get("Authorization", "")
    api_key = request.headers.get("X-Api-Key", "")
    token = api_key or auth.replace("Bearer ", "", 1)

    model = chat_req.get("model", "") if isinstance(chat_req, dict) else ""
    is_stream = bool(isinstance(chat_req, dict) and chat_req.get("stream", False))
    incoming_messages = chat_req.get("messages", []) if isinstance(chat_req, dict) else []
    incoming_messages_count = len(incoming_messages) if isinstance(incoming_messages, list) else 0
    has_input_field = bool(isinstance(chat_req, dict) and chat_req.get("input"))
    has_previous_response_id = bool(isinstance(chat_req, dict) and chat_req.get("previous_response_id"))

    _log_node(
        trace_id,
        route,
        "request.received",
        model=model,
        stream=is_stream,
        messages=incoming_messages_count,
        has_input=has_input_field,
        has_previous_response_id=has_previous_response_id,
    )
    _log_payload_shape(trace_id, "chat/completions incoming payload shape", chat_req)

    openai_req = build_openai_request_from_chat(chat_req)
    openai_req = _sanitize_upstream_payload(openai_req)
    converted_input = openai_req.get("input")
    converted_input_count = len(converted_input) if isinstance(converted_input, list) else 0

    _log_node(
        trace_id,
        route,
        "request.converted",
        input_items=converted_input_count,
        has_tools=("tools" in openai_req),
        has_instructions=("instructions" in openai_req),
    )
    _log_payload_shape(trace_id, "chat/completions outgoing payload shape", openai_req)

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token}",
    }
    return model, is_stream, openai_req, headers


def _call_chat_upstream(request: web.Request, openai_req, headers, trace_id, route, is_stream):
    target_url = f"{TARGET_BASE_URL}{TARGET_PATH}"
    session = _get_upstream_session(request)
    _log_node(trace_id, route, "upstream.request.sending", method="POST", path=TARGET_PATH, stream=is_stream)
    return session.post(target_url, json=openai_req, headers=headers)


async def _handle_chat_non_stream(resp, model, trace_id, route, started_at):
    openai_resp = await _read_upstream_json_or_sse(resp, trace_id=trace_id, route=route)
    _log_node(trace_id, route, "upstream.response.body.received", mode="non_stream")
    _log_payload_shape(trace_id, "chat/completions upstream payload shape", openai_resp)
    chat_resp = build_chat_completions_response(openai_resp, model)
    _log_payload_shape(trace_id, "chat/completions return payload shape", chat_resp)
    _log_node(
        trace_id,
        route,
        "downstream.response.sent",
        mode="non_stream",
        elapsed_ms=int((time.time() - started_at) * 1000),
    )
    return web.json_response(chat_resp)


async def _handle_chat_stream(request: web.Request, resp, model, trace_id, route, started_at):
    converter = ChatStreamConverter(model)
    parser = SSEEventParser()
    ctx = RequestContext(trace_id, route, started_at, model, True, True)
    response = web.StreamResponse(
        status=200,
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )
    await response.prepare(request)
    await _write_initial_sse_ping(response)
    _log_node(trace_id, route, "downstream.stream.prepared")
    writer = _StreamEventBatchWriter(response, STREAM_WRITE_BATCH_LIMIT)

    upstream_chunks = 0
    upstream_bytes = 0
    parsed_events = 0
    converted_events = 0

    async def _queue_converted_events(converted):
        nonlocal converted_events
        converted_events += len(converted)
        await writer.write_many(converted)

    async for raw_chunk in resp.content:
        upstream_chunks += 1
        upstream_bytes += len(raw_chunk)
        chunk_text = raw_chunk.decode("utf-8", errors="replace")
        for event_payload in parser.feed_text(chunk_text):
            parsed_delta, converted = _process_stream_event_payload(event_payload, converter, ctx)
            parsed_events += parsed_delta
            await _queue_converted_events(converted)

    for event_payload in parser.finalize():
        parsed_delta, converted = _process_stream_event_payload(event_payload, converter, ctx, trailing=True)
        parsed_events += parsed_delta
        await _queue_converted_events(converted)

    if not converter.started or not converter.finished:
        await _queue_converted_events(converter.convert("response.completed", {"response": {"status": "completed"}}))

    await writer.flush()
    await response.write_eof()
    _log_node(
        trace_id,
        route,
        "downstream.stream.completed",
        elapsed_ms=int((time.time() - started_at) * 1000),
        upstream_chunks=upstream_chunks,
        upstream_bytes=upstream_bytes,
        parsed_events=parsed_events,
        converted_events=converted_events,
        finished=converter.finished,
    )
    return response


async def handle_chat_completions(request: web.Request):
    """OpenAI Chat Completions-compatible endpoint: forwards to upstream Responses API.

    In `chat` protocol mode, uses the standard handler; otherwise maps to
    `/v1/responses` with conversion.
    """
    trace_id = request.headers.get("X-Request-Id") or f"req_{uuid.uuid4().hex[:12]}"
    route = "v1/chat/completions"
    started_at = time.time()

    try:
        chat_req = await request.json()
    except Exception:
        _log_node(trace_id, route, "request.parse.failed", error="invalid_json")
        return web.json_response({"error": "Invalid JSON"}, status=400)

    auth = request.headers.get("Authorization", "")
    api_key = request.headers.get("X-Api-Key", "")
    token = api_key or auth.replace("Bearer ", "", 1)

    if CHAT_COMPLETIONS_PROTOCOL == "standard":
        return await _handle_chat_completions_standard(request, chat_req, token, trace_id, started_at)

    model, is_stream, openai_req, headers = _prepare_chat_request(request, chat_req, trace_id, route)

    try:
        async with _call_chat_upstream(request, openai_req, headers, trace_id, route, is_stream) as resp:
            _log_node(
                trace_id,
                route,
                "upstream.response.headers",
                status=resp.status,
                content_type=resp.headers.get("Content-Type", ""),
            )
            if resp.status != 200:
                body = await resp.text()
                _log_node(trace_id, route, "upstream.response.error", status=resp.status, body_preview=body[:500])
                return web.json_response({"error": {"message": body, "type": "api_error"}}, status=resp.status)

            if not is_stream:
                return await _handle_chat_non_stream(resp, model, trace_id, route, started_at)
            return await _handle_chat_stream(request, resp, model, trace_id, route, started_at)

    except asyncio.TimeoutError:
        _log_node(trace_id, route, "error.gateway.timeout", elapsed_ms=int((time.time() - started_at) * 1000))
        return web.json_response({"error": {"message": "Gateway timeout", "type": "timeout_error"}}, status=504)
    except (ConnectionResetError, BrokenPipeError, asyncio.CancelledError) as e:
        _log_node(trace_id, route, "error.client_disconnected", error=str(e))
        return web.Response(status=499, text="Client Closed Request")
    except Exception as e:
        _log_node(
            trace_id,
            route,
            "error.proxy.exception",
            elapsed_ms=int((time.time() - started_at) * 1000),
            error=str(e),
        )
        return web.json_response({"error": {"message": str(e), "type": "api_error"}}, status=502)


def _build_cors_headers():
    return {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Authorization, Content-Type, X-Api-Key, Anthropic-Version, Anthropic-Beta",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    }


def _json_response_with_cors(payload, status=200):
    resp = web.json_response(payload, status=status)
    resp.headers.update(_build_cors_headers())
    return resp


async def handle_options(request):
    return web.Response(status=204, headers=_build_cors_headers())


async def handle_models(request):
    models = get_advertised_models()

    now_ts = int(time.time())
    data = [
        {
            "id": model_name,
            "object": "model",
            "created": now_ts,
            "owned_by": "anthropic-proxy",
        }
        for model_name in models
    ]
    return _json_response_with_cors({"object": "list", "data": data})


async def handle_health(request):
    """Liveness probe for load balancers / health checks."""
    return _json_response_with_cors({"status": "ok"})


async def handle_root_get(request):
    """Root endpoint for simple availability checks."""
    return _json_response_with_cors({"status": "ok"})


async def handle_root_head(request):
    """HEAD probe for runtimes that ping '/' with HEAD."""
    return web.Response(status=200, headers=_build_cors_headers())


# ========== Main ==========


def main():
    """Start aiohttp app and register routes."""
    app = web.Application()
    app.on_startup.append(_on_startup)
    app.on_cleanup.append(_on_cleanup)
    app.router.add_post("/v1/messages", handle_messages)
    app.router.add_post("/v1/chat/completions", handle_chat_completions)
    app.router.add_post("/v1/responses", handle_responses)
    app.router.add_get("/v1/models", handle_models)
    app.router.add_get("/health", handle_health)
    app.router.add_get("/", handle_root_get)

    app.router.add_route("OPTIONS", "/v1/messages", handle_options)
    app.router.add_route("OPTIONS", "/v1/chat/completions", handle_options)
    app.router.add_route("OPTIONS", "/v1/responses", handle_options)
    app.router.add_route("OPTIONS", "/v1/models", handle_options)
    app.router.add_route("OPTIONS", "/health", handle_options)
    app.router.add_route("OPTIONS", "/", handle_options)

    logger.info("Anthropic proxy started: http://localhost:%d", LOCAL_PORT)
    logger.info("Protocol mode: %s", PROTOCOL_MODE)
    logger.info(
        "Messages upstream: mode=%s path=%s",
        MESSAGES_UPSTREAM_MODE,
        TARGET_MESSAGES_PATH,
    )
    if MESSAGES_MODEL_OVERRIDE:
        logger.info("Messages model override: %s", MESSAGES_MODEL_OVERRIDE)
    if MESSAGES_FORCE_NON_STREAM_RESPONSE:
        logger.info("Messages downstream mode: force_non_stream=true")
    logger.info(
        "ChatCompletions protocol: %s (upstream path: %s)",
        CHAT_COMPLETIONS_PROTOCOL,
        TARGET_CHAT_COMPLETIONS_PATH,
    )

    web.run_app(app, host="0.0.0.0", port=LOCAL_PORT)


if __name__ == "__main__":
    main()










