﻿# OpenCode 配置教程

## 1. 安装

```bash
npm i -g opencode-ai
```

## 2. 首次启动

```bash
opencode
```

启动后按 `Ctrl + C` 退出。

## 3. 放入配置文件

打开目录 `~/.config/opencode`（Windows 下即 `C:\Users\你的用户名\.config\opencode`），编辑 `opencode.json` 。

当前配置文件内容(注意key与url)：

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "openai": {
      "options": {
        "apiKey": "",
        "baseURL": ""
      },
      "models": {
        "gpt-5.3-codex": {
          "name": "gpt-5.3-codex"
        }
      }
    }
  }
}
```

## 4. 再次启动并选择模型

```bash
opencode
```

启动后在输入框中输入 `/model`，按 `Ctrl + A` 选择 `openai`，再选择模型 `gpt-5.3-codex`。

## 5. 下载使用客户端

客户端与cli的配置是互通的,官网下载客户端直接使用即可

https://opencode.ai/