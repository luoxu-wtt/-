"""
Standard-mode request builder for /v1/chat/completions.

Cursor sends Responses API format directly (with `input`, `tools`, etc.).
The upstream /developer/v1/chat/completions also speaks Responses API.
This module does minimal sanitisation — strip fields the upstream rejects
and pass everything else through.
"""

import logging

logger = logging.getLogger("anthropic-proxy")

_MODELS_WITHOUT_PROMPT_CACHE = {"codex", "o1", "o3", "o4"}

_UPSTREAM_ALLOWED_KEYS = frozenset({
    "model",
    "stream",
    "input",
    "instructions",
    "max_output_tokens",
    "temperature",
    "top_p",
    "tools",
    "tool_choice",
    "reasoning",
    "previous_response_id",
    "text",
    "parallel_tool_calls",
    "truncation",
})


def build_openai_chat_mode_request(chat_req):
    """Build upstream Responses API payload from Cursor's chat/completions request.

    Cursor already sends Responses API format (input, tools, etc.), so we
    only need to whitelist allowed keys and strip incompatible ones.
    """
    if not isinstance(chat_req, dict):
        return chat_req

    sanitized = {}
    dropped_keys = []

    for key, value in chat_req.items():
        if "." in key:
            dropped_keys.append(key)
            continue

        if key == "stream_options":
            dropped_keys.append(key)
            continue

        if key not in _UPSTREAM_ALLOWED_KEYS:
            dropped_keys.append(key)
            continue

        sanitized[key] = value

    text_cfg = sanitized.get("text")
    if isinstance(text_cfg, dict):
        text_cfg = dict(text_cfg)
        if text_cfg.get("verbosity") not in (None, "medium"):
            text_cfg["verbosity"] = "medium"
        sanitized["text"] = text_cfg

    if dropped_keys:
        logger.info(
            "standard-mode request sanitized: dropped_keys=%s",
            dropped_keys,
        )

    return sanitized
