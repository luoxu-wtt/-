import json
import unittest

from anthropic_proxy import (
    SSEEventParser,
    _extract_json_from_sse_body,
    _normalize_responses_upstream_request,
    _normalize_strict_responses_payload,
    _sanitize_upstream_payload,
    convert_tools_a2o,
)
from chat_to_responses_converter import (
    ChatStreamConverter,
    build_openai_request_from_chat,
    convert_chat_messages_to_responses_input,
    convert_chat_tools_to_responses,
)
from chat_mode_request_converter import build_openai_chat_mode_request


class ToolNameValidationTests(unittest.TestCase):
    def test_convert_tools_a2o_filters_empty_or_missing_name(self):
        anthropic_tools = [
            {"name": "search_docs", "description": "ok", "input_schema": {"type": "object"}},
            {"description": "missing name"},
            {"name": ""},
            {"name": "   "},
            "not_a_dict",
        ]

        with self.assertLogs("anthropic-proxy", level="WARNING") as captured:
            converted = convert_tools_a2o(anthropic_tools)

        self.assertEqual(len(converted), 1)
        self.assertEqual(converted[0]["name"], "search_docs")
        self.assertIn("Filtered 4 invalid anthropic tools", "\n".join(captured.output))

    def test_convert_chat_tools_to_responses_filters_invalid_function_name(self):
        chat_tools = [
            {
                "type": "function",
                "function": {
                    "name": "run_query",
                    "description": "ok",
                    "parameters": {"type": "object"},
                },
            },
            {},
            {"type": "function", "function": {}},
            {"type": "function", "function": {"name": "   "}},
            {"type": "function", "function": "not_a_dict"},
            "not_a_dict",
        ]

        with self.assertLogs("anthropic-proxy", level="WARNING") as captured:
            converted = convert_chat_tools_to_responses(chat_tools)

        self.assertEqual(len(converted), 1)
        self.assertEqual(converted[0]["name"], "run_query")
        self.assertIn("Filtered 4 invalid chat tools", "\n".join(captured.output))

    def test_convert_tools_return_none_when_all_invalid(self):
        self.assertIsNone(convert_tools_a2o([{"name": "   "}, {}]))
        self.assertIsNone(convert_chat_tools_to_responses([{"type": "function", "function": {}}]))

    def test_build_openai_request_from_chat_prefers_input_over_messages(self):
        chat_req = {
            "model": "gpt-test",
            "messages": [{"role": "user", "content": "from messages"}],
            "input": [{"role": "user", "content": [{"type": "input_text", "text": "from input"}]}],
            "include": ["reasoning.encrypted_content"],
            "reasoning": {"effort": "medium"},
            "metadata": {"source": "cursor"},
            "text": {"format": {"type": "text"}},
            "stream_options": {"include_usage": True},
            "prompt_cache_retention": "24h",
            "user": "u_123",
            "store": True,
            "previous_response_id": "resp_abc",
        }

        converted = build_openai_request_from_chat(chat_req)

        self.assertEqual(converted["input"], chat_req["input"])
        self.assertEqual(converted["include"], chat_req["include"])
        self.assertEqual(converted["reasoning"], chat_req["reasoning"])
        self.assertEqual(converted["metadata"], chat_req["metadata"])
        self.assertEqual(converted["text"], chat_req["text"])
        self.assertNotIn("stream_options", converted)
        self.assertEqual(converted["user"], chat_req["user"])
        self.assertEqual(converted["store"], chat_req["store"])
        self.assertEqual(converted["previous_response_id"], chat_req["previous_response_id"])
        self.assertEqual(converted["prompt_cache_retention"], chat_req["prompt_cache_retention"])

    def test_build_openai_chat_mode_request_prefers_input_over_messages(self):
        chat_req = {
            "model": "gpt-test",
            "messages": [{"role": "user", "content": "from messages"}],
            "input": "1+1",
            "stream_options": {"include_usage": True},
        }
        converted = build_openai_chat_mode_request(chat_req)
        self.assertEqual(converted["input"], "1+1")
        self.assertNotIn("stream_options", converted)

    def test_build_openai_chat_mode_request_drops_messages_and_unknown_keys(self):
        chat_req = {
            "model": "gpt-test",
            "messages": [{"role": "user", "content": "hello"}],
            "stream": True,
            "unknown_field": "should_be_dropped",
        }
        converted = build_openai_chat_mode_request(chat_req)
        self.assertEqual(converted["stream"], True)
        self.assertNotIn("messages", converted)
        self.assertNotIn("unknown_field", converted)
        self.assertNotIn("input", converted)

    def test_convert_chat_messages_supports_input_text_blocks(self):
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "input_text", "text": "hello"},
                    {"type": "text", "text": "world"},
                ],
            }
        ]

        converted = convert_chat_messages_to_responses_input(messages)
        self.assertEqual(
            converted,
            [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": "hello"},
                        {"type": "input_text", "text": "world"},
                    ],
                }
            ],
        )

    def test_convert_chat_messages_supports_image_blocks(self):
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "look at this"},
                    {"type": "image_url", "image_url": {"url": "https://example.com/a.png"}},
                ],
            }
        ]

        converted = convert_chat_messages_to_responses_input(messages)
        self.assertEqual(
            converted,
            [
                {
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": "look at this"},
                        {"type": "input_image", "image_url": "https://example.com/a.png"},
                    ],
                }
            ],
        )

    def test_convert_chat_tools_to_responses_accepts_flattened_tool_schema(self):
        chat_tools = [
            {
                "type": "function",
                "name": "lookup_user",
                "description": "Query user profile",
                "parameters": {"type": "object", "properties": {"uid": {"type": "string"}}},
            }
        ]

        with self.assertNoLogs("anthropic-proxy", level="WARNING"):
            converted = convert_chat_tools_to_responses(chat_tools)

        self.assertEqual(len(converted), 1)
        self.assertEqual(converted[0]["name"], "lookup_user")
        self.assertEqual(converted[0]["description"], "Query user profile")

    def test_build_openai_request_from_chat_omits_empty_input_without_previous_response(self):
        chat_req = {
            "model": "gpt-test",
            "stream": True,
            "messages": [],
            "input": [],
        }

        converted = build_openai_request_from_chat(chat_req)
        self.assertNotIn("input", converted)

    def test_build_openai_request_from_chat_does_not_duplicate_system_or_developer_into_input(self):
        chat_req = {
            "model": "gpt-test",
            "messages": [
                {"role": "system", "content": "system policy"},
                {"role": "developer", "content": "developer guardrails"},
                {"role": "user", "content": "hello"},
            ],
        }

        converted = build_openai_request_from_chat(chat_req)
        self.assertEqual(converted["instructions"], "system policy\n\ndeveloper guardrails")
        self.assertEqual(converted["input"], [{"role": "user", "content": "hello"}])

    def test_build_openai_request_from_chat_normalizes_text_verbosity_to_medium(self):
        chat_req = {
            "model": "gpt-test",
            "messages": [{"role": "user", "content": "hello"}],
            "text": {"verbosity": "low", "format": {"type": "text"}},
        }

        converted = build_openai_request_from_chat(chat_req)
        self.assertEqual(converted["text"]["verbosity"], "medium")

    def test_sanitize_upstream_payload_removes_stream_options_include_usage(self):
        payload = {
            "model": "gpt-test",
            "stream_options": {"include_usage": True},
        }
        sanitized = _sanitize_upstream_payload(payload)
        self.assertNotIn("stream_options", sanitized)

    def test_sanitize_upstream_payload_removes_stream_options_entirely(self):
        payload = {
            "model": "gpt-test",
            "stream_options": {"include_usage": True, "foo": "bar"},
        }
        sanitized = _sanitize_upstream_payload(payload)
        self.assertNotIn("stream_options", sanitized)

    def test_sanitize_upstream_payload_removes_flattened_key_recursively(self):
        payload = {
            "model": "gpt-test",
            "metadata": {
                "stream_options.include_usage": True,
                "nested": {"stream_options.include_usage": True, "ok": 1},
            },
        }
        sanitized = _sanitize_upstream_payload(payload)
        self.assertEqual(sanitized["metadata"], {"nested": {"ok": 1}})

    def test_sanitize_upstream_payload_removes_flattened_stream_options_include_usage(self):
        payload = {
            "model": "gpt-test",
            "stream_options.include_usage": True,
        }
        sanitized = _sanitize_upstream_payload(payload)
        self.assertNotIn("stream_options.include_usage", sanitized)

    def test_sanitize_upstream_payload_defaults_empty_pages_to_one(self):
        payload = {
            "model": "gpt-test",
            "pages": None,
            "nested": {"pages": "   ", "other_null": None},
        }
        sanitized = _sanitize_upstream_payload(payload)
        self.assertEqual(sanitized["pages"], "1")
        self.assertEqual(sanitized["nested"]["pages"], "1")
        self.assertIsNone(sanitized["nested"]["other_null"])

    def test_chat_stream_converter_maps_function_args_delta_by_item_id(self):
        converter = ChatStreamConverter("gpt-test")

        converter.convert(
            "response.output_item.added",
            {
                "item": {
                    "type": "function_call",
                    "id": "fc_item_1",
                    "call_id": "call_1",
                    "name": "lookup_user",
                }
            },
        )
        events = converter.convert(
            "response.function_call_arguments.delta",
            {"item_id": "fc_item_1", "delta": "{\"uid\":\"u_1\"}"},
        )

        self.assertEqual(len(events), 1)
        payload = json.loads(events[0][len("data: "):].strip())
        tool_delta = payload["choices"][0]["delta"]["tool_calls"][0]
        self.assertEqual(tool_delta["index"], 0)
        self.assertEqual(tool_delta["function"]["arguments"], "{\"uid\":\"u_1\"}")

    def test_chat_stream_converter_falls_back_to_completed_output_text(self):
        converter = ChatStreamConverter("gpt-test")

        events = converter.convert(
            "response.completed",
            {
                "response": {
                    "status": "completed",
                    "output": [
                        {
                            "type": "message",
                            "content": [{"type": "output_text", "text": "hello from completed"}],
                        }
                    ],
                }
            },
        )

        self.assertGreaterEqual(len(events), 3)
        content_event = None
        finish_event = None
        for raw in events:
            if not raw.startswith("data: ") or raw == "data: [DONE]\n\n":
                continue
            payload = json.loads(raw[len("data: "):].strip())
            delta = payload["choices"][0]["delta"]
            if "content" in delta:
                content_event = payload
            if payload["choices"][0]["finish_reason"] is not None:
                finish_event = payload

        self.assertIsNotNone(content_event)
        self.assertEqual(content_event["choices"][0]["delta"]["content"], "hello from completed")
        self.assertIsNotNone(finish_event)
        self.assertEqual(finish_event["choices"][0]["finish_reason"], "stop")
        self.assertEqual(events[-1], "data: [DONE]\n\n")

    def test_chat_stream_converter_supports_output_item_done_message(self):
        converter = ChatStreamConverter("gpt-test")

        events = converter.convert(
            "response.output_item.done",
            {
                "item": {
                    "type": "message",
                    "content": [{"type": "output_text", "text": "hello from item.done"}],
                }
            },
        )

        content_event = None
        for raw in events:
            if not raw.startswith("data: ") or raw == "data: [DONE]\n\n":
                continue
            payload = json.loads(raw[len("data: "):].strip())
            delta = payload["choices"][0]["delta"]
            if "content" in delta:
                content_event = payload
                break

        self.assertIsNotNone(content_event)
        self.assertEqual(content_event["choices"][0]["delta"]["content"], "hello from item.done")


    def test_chat_stream_converter_extracts_from_lifecycle_events(self):
        """Gateway sends only created/in_progress/completed with output packed inside."""
        converter = ChatStreamConverter("gpt-test")

        converter.convert(
            "response.created",
            {
                "response": {
                    "id": "resp_abc",
                    "status": "in_progress",
                    "output": [],
                }
            },
        )

        converter.convert(
            "response.in_progress",
            {
                "response": {
                    "id": "resp_abc",
                    "status": "in_progress",
                    "output": [
                        {
                            "type": "message",
                            "content": [{"type": "output_text", "text": "packed content"}],
                        }
                    ],
                }
            },
        )

        events = converter.convert(
            "response.completed",
            {
                "response": {
                    "id": "resp_abc",
                    "status": "completed",
                    "output": [
                        {
                            "type": "message",
                            "content": [{"type": "output_text", "text": "packed content"}],
                        }
                    ],
                }
            },
        )

        all_events = []
        all_events.extend(converter.convert.__self__.convert("response.created", {
            "response": {"status": "in_progress", "output": []}
        }))

        converter2 = ChatStreamConverter("gpt-test")
        all_events2 = []
        all_events2.extend(converter2.convert(
            "response.created",
            {"response": {"status": "in_progress", "output": [
                {"type": "message", "content": [{"type": "output_text", "text": "from created"}]},
            ]}},
        ))
        all_events2.extend(converter2.convert(
            "response.completed",
            {"response": {"status": "completed", "output": [
                {"type": "message", "content": [{"type": "output_text", "text": "from created"}]},
            ]}},
        ))

        content_found = False
        for raw in all_events2:
            if not raw.startswith("data: ") or raw == "data: [DONE]\n\n":
                continue
            payload = json.loads(raw[len("data: "):].strip())
            delta = payload["choices"][0]["delta"]
            if "content" in delta and delta["content"] == "from created":
                content_found = True
                break

        self.assertTrue(content_found, "Content from response.created output should appear in chat stream")
        self.assertTrue(converter2.finished)


class SSEEventParserTests(unittest.TestCase):
    def test_parser_emits_event_after_blank_line(self):
        parser = SSEEventParser()

        emitted = parser.feed_text('event: response.created\ndata: {"type":"response.created"}\n\n')

        self.assertEqual(len(emitted), 1)
        self.assertEqual(emitted[0]["event"], "response.created")
        self.assertEqual(emitted[0]["data"], '{"type":"response.created"}')

    def test_parser_merges_multiline_data(self):
        parser = SSEEventParser()

        emitted = parser.feed_text('event: response.output_text.delta\ndata: {"type":"response.output_text.delta",\ndata: "delta":"hi"}\n\n')

        self.assertEqual(len(emitted), 1)
        self.assertIn('"delta":"hi"', emitted[0]["data"])
        self.assertIn('response.output_text.delta', emitted[0]["data"])

    def test_parser_finalize_flushes_trailing_event(self):
        parser = SSEEventParser()

        emitted = parser.feed_text('event: response.completed\ndata: {"type":"response.completed"}')
        trailing = parser.finalize()

        self.assertEqual(emitted, [])
        self.assertEqual(len(trailing), 1)
        self.assertEqual(trailing[0]["event"], "response.completed")

    def test_extract_json_from_sse_body_skips_done_and_returns_response(self):
        raw = "\n".join(
            [
                "event: response.created",
                'data: {"type":"response.created","response":{"id":"resp_1"}}',
                "",
                "data: [DONE]",
                "",
                "event: response.completed",
                'data: {"type":"response.completed","response":{"object":"response","output":[]}}',
                "",
            ]
        )

        parsed = _extract_json_from_sse_body(raw)

        self.assertIsInstance(parsed, dict)
        self.assertEqual(parsed.get("object"), "response")




class StrictResponsesPayloadTests(unittest.TestCase):
    def test_strict_payload_keeps_upstream_fields(self):
        payload = {
            "id": "resp_test",
            "created_at": 1774959897,
            "status": "completed",
            "model": "gpt-5.4-pro",
            "output": [{"type": "message"}],
            "usage": {"input_tokens": 9, "output_tokens": 5, "total_tokens": 14},
            "temperature": 0.2,
            "top_p": 0.9,
            "text": {"format": {"type": "text"}, "verbosity": "high"},
        }

        normalized = _normalize_strict_responses_payload(payload, request_model="")

        self.assertEqual(normalized["id"], "resp_test")
        self.assertEqual(normalized["created_at"], 1774959897)
        self.assertEqual(normalized["temperature"], 0.2)
        self.assertEqual(normalized["top_p"], 0.9)
        self.assertEqual(normalized["text"]["verbosity"], "high")

    def test_strict_payload_backfills_required_defaults(self):
        normalized = _normalize_strict_responses_payload({"output": []}, request_model="gpt-5.4-pro")

        self.assertEqual(normalized["object"], "response")
        self.assertEqual(normalized["model"], "gpt-5.4-pro")
        self.assertEqual(normalized["status"], "completed")
        self.assertEqual(normalized["background"], False)
        self.assertEqual(normalized["parallel_tool_calls"], True)
        self.assertEqual(normalized["reasoning"]["effort"], "medium")
        self.assertEqual(normalized["text"]["format"]["type"], "text")
        self.assertEqual(normalized["text"]["verbosity"], "medium")
        self.assertEqual(normalized["usage"]["input_tokens_details"]["cached_tokens"], 0)
        self.assertEqual(normalized["usage"]["output_tokens_details"]["reasoning_tokens"], 0)


class ResponsesRequestNormalizationTests(unittest.TestCase):
    def test_messages_are_mapped_to_input_for_responses(self):
        req = {
            "model": "gpt-5.4-pro",
            "messages": [{"role": "user", "content": "1+1"}],
        }

        normalized = _normalize_responses_upstream_request(req, client_wants_stream=False)

        self.assertNotIn("messages", normalized)
        self.assertEqual(normalized["input"], [{"role": "user", "content": "1+1"}])
        self.assertEqual(normalized["stream"], False)

    def test_existing_input_is_preserved_when_messages_present(self):
        req = {
            "model": "gpt-5.4-pro",
            "messages": [{"role": "user", "content": "from messages"}],
            "input": "from input",
        }

        normalized = _normalize_responses_upstream_request(req, client_wants_stream=True)

        self.assertNotIn("messages", normalized)
        self.assertEqual(normalized["input"], "from input")
        self.assertEqual(normalized["stream"], True)

    def test_max_tokens_is_mapped_to_max_output_tokens(self):
        req = {
            "model": "gpt-5.4-pro",
            "input": "hello",
            "max_tokens": 123,
        }

        normalized = _normalize_responses_upstream_request(req, client_wants_stream=False)

        self.assertEqual(normalized["max_output_tokens"], 123)
        self.assertNotIn("max_tokens", normalized)

    def test_max_completion_tokens_is_mapped_to_max_output_tokens(self):
        req = {
            "model": "gpt-5.4-pro",
            "input": "hello",
            "max_completion_tokens": 77,
        }

        normalized = _normalize_responses_upstream_request(req, client_wants_stream=False)

        self.assertEqual(normalized["max_output_tokens"], 77)
        self.assertNotIn("max_completion_tokens", normalized)

    def test_anthropic_shape_reuses_messages_converter(self):
        req = {
            "model": "gpt-5.4-pro",
            "messages": [{"role": "user", "content": "hi"}],
            "system": "sys policy",
            "max_tokens": 42,
            "tools": [{"name": "lookup", "description": "d", "input_schema": {"type": "object"}}],
        }

        normalized = _normalize_responses_upstream_request(req, client_wants_stream=False)

        self.assertNotIn("messages", normalized)
        self.assertEqual(normalized.get("max_output_tokens"), 42)
        self.assertEqual(normalized.get("instructions"), "sys policy")
        self.assertTrue(isinstance(normalized.get("input"), list) and len(normalized["input"]) > 0)
        self.assertTrue(isinstance(normalized.get("tools"), list) and normalized["tools"][0].get("type") == "function")

class PublicResponsesStreamFormatTests(unittest.TestCase):
    def test_public_stream_client_gets_simulated_sse_when_upstream_json(self):
        sample = {
            "id": "resp_x",
            "status": "completed",
            "model": "gpt-5.4-pro",
            "output": [],
            "usage": {"input_tokens": 1, "output_tokens": 1, "total_tokens": 2},
        }
        # This asserts formatter expectations used by public handler fallback.
        normalized = _normalize_strict_responses_payload(sample, request_model="gpt-5.4-pro")
        self.assertEqual(normalized["object"], "response")
        self.assertEqual(normalized["status"], "completed")



if __name__ == "__main__":
    unittest.main()
