import json
import logging
import time
import uuid

COMPLETION_OBJECT = "chat.completion"
COMPLETION_CHUNK_OBJECT = "chat.completion.chunk"

logger = logging.getLogger("anthropic-proxy")


def _extract_text(value):
    if isinstance(value, list):
        texts = []
        for part in value:
            if isinstance(part, dict):
                ptype = part.get("type")
                if ptype in ("text", "input_text", "output_text"):
                    texts.append(part.get("text", ""))
                else:
                    texts.append(str(part))
            else:
                texts.append(str(part))
        return "\n".join(texts)
    if value is None:
        return ""
    return str(value)


def _normalize_tool_name(name):
    if name is None:
        return ""
    return str(name).strip()


def convert_chat_tools_to_responses(chat_tools):
    if not chat_tools:
        return None
    out = []
    filtered_count = 0
    for tool in chat_tools:
        if not isinstance(tool, dict):
            filtered_count += 1
            continue
        if tool.get("type") != "function":
            continue
        fn = tool.get("function", {})
        if fn is None:
            fn = {}
        if not isinstance(fn, dict):
            filtered_count += 1
            continue
        tool_name = _normalize_tool_name(tool.get("name") or fn.get("name"))
        if not tool_name:
            filtered_count += 1
            continue
        out.append({
            "type": "function",
            "name": tool_name,
            "description": tool.get("description", fn.get("description", "")),
            "parameters": tool.get("parameters", fn.get("parameters", {"type": "object", "properties": {}})),
        })
    if filtered_count:
        logger.warning(
            "Filtered %d invalid chat tools with empty/missing name or function.name",
            filtered_count,
        )
    return out or None


def convert_chat_messages_to_responses_input(messages):
    items = []
    for msg in messages or []:
        role = msg.get("role")
        content = msg.get("content", "")

        if role == "tool":
            tool_call_id = msg.get("tool_call_id", "")
            if isinstance(content, list):
                content = _extract_text(content)
            items.append({
                "type": "function_call_output",
                "call_id": tool_call_id,
                "output": str(content) if content is not None else "",
            })
            continue

        if role == "assistant":
            tool_calls = msg.get("tool_calls", []) or []
            if content:
                text = _extract_text(content)
                items.append({
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": text}],
                })

            for tc in tool_calls:
                fn = tc.get("function", {})
                items.append({
                    "type": "function_call",
                    "id": f"fc_{uuid.uuid4().hex[:24]}",
                    "call_id": tc.get("id", f"call_{uuid.uuid4().hex[:24]}"),
                    "name": fn.get("name", ""),
                    "arguments": fn.get("arguments", "{}"),
                })
            continue

        # system/developer are mapped into `instructions`; avoid duplicating
        # them as user turns in `input`.
        if role == "user":
            if isinstance(content, list):
                blocks = []
                for part in content:
                    if not isinstance(part, dict):
                        blocks.append({"type": "input_text", "text": str(part)})
                        continue
                    ptype = part.get("type")
                    if ptype in ("text", "input_text"):
                        blocks.append({"type": "input_text", "text": part.get("text", "")})
                    elif ptype == "image_url":
                        image_url = part.get("image_url")
                        if isinstance(image_url, dict):
                            image_url = image_url.get("url")
                        if image_url:
                            blocks.append({"type": "input_image", "image_url": str(image_url)})
                    elif ptype == "input_image":
                        image_url = part.get("image_url")
                        if image_url:
                            blocks.append({"type": "input_image", "image_url": str(image_url)})
                if blocks:
                    items.append({"role": "user", "content": blocks})
            else:
                items.append({"role": "user", "content": str(content)})

    return items


def extract_chat_instructions(messages):
    system_texts = []
    for msg in messages or []:
        if msg.get("role") in ("system", "developer"):
            content = msg.get("content", "")
            if isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        system_texts.append(part.get("text", ""))
            else:
                system_texts.append(str(content))
    text = "\n\n".join(t for t in system_texts if t)
    return text or None


_MODELS_WITHOUT_PROMPT_CACHE = {"codex", "o1", "o3", "o4"}


def _model_supports_prompt_cache(model_name):
    if not model_name:
        return False
    lower = model_name.lower()
    return not any(tag in lower for tag in _MODELS_WITHOUT_PROMPT_CACHE)


def sanitize_responses_request_for_target(payload):
    if not isinstance(payload, dict):
        return payload
    sanitized = dict(payload)

    dotted_keys = [k for k in sanitized if "." in k]
    for key in dotted_keys:
        sanitized.pop(key, None)

    sanitized.pop("stream_options", None)

    model = sanitized.get("model", "")

    text_cfg = sanitized.get("text")
    if isinstance(text_cfg, dict):
        text_cfg = dict(text_cfg)
        if "verbosity" in text_cfg and text_cfg.get("verbosity") != "medium":
            text_cfg["verbosity"] = "medium"
        sanitized["text"] = text_cfg

    if "prompt_cache_retention" in sanitized and not _model_supports_prompt_cache(model):
        sanitized.pop("prompt_cache_retention", None)

    return sanitized


def build_openai_request_from_chat(chat_req):
    incoming_input = chat_req.get("input")
    converted_messages_input = convert_chat_messages_to_responses_input(chat_req.get("messages", []))

    use_incoming_input = incoming_input not in (None, "", [], {})
    use_converted_messages = bool(converted_messages_input)

    openai_req = {
        "model": chat_req.get("model", ""),
        "stream": chat_req.get("stream", False),
    }
    if use_incoming_input:
        openai_req["input"] = incoming_input
    elif use_converted_messages:
        openai_req["input"] = converted_messages_input

    instructions = extract_chat_instructions(chat_req.get("messages", []))
    if instructions:
        openai_req["instructions"] = instructions

    if "max_completion_tokens" in chat_req:
        openai_req["max_output_tokens"] = chat_req["max_completion_tokens"]
    elif "max_tokens" in chat_req:
        openai_req["max_output_tokens"] = chat_req["max_tokens"]

    if "temperature" in chat_req:
        openai_req["temperature"] = chat_req["temperature"]
    if "top_p" in chat_req:
        openai_req["top_p"] = chat_req["top_p"]

    tools = convert_chat_tools_to_responses(chat_req.get("tools"))
    if tools:
        openai_req["tools"] = tools

    tool_choice = chat_req.get("tool_choice")
    if tool_choice is not None:
        openai_req["tool_choice"] = tool_choice

    passthrough_fields = (
        "include",
        "reasoning",
        "metadata",
        "user",
        "store",
        "previous_response_id",
        "prompt_cache_retention",
    )
    for field in passthrough_fields:
        if field in chat_req:
            openai_req[field] = chat_req[field]

    text_cfg = chat_req.get("text")
    if isinstance(text_cfg, dict):
        openai_req["text"] = dict(text_cfg)

    return sanitize_responses_request_for_target(openai_req)


def _map_finish_reason_for_chat(stop_reason):
    if stop_reason == "tool_use":
        return "tool_calls"
    if stop_reason == "max_tokens":
        return "length"
    return "stop"


def build_chat_completions_response(openai_resp, model):
    text_parts = []
    tool_calls = []

    for item in openai_resp.get("output", []):
        if item.get("type") == "message":
            for part in item.get("content", []):
                if part.get("type") == "output_text":
                    text_parts.append(part.get("text", ""))
        elif item.get("type") == "function_call":
            tool_calls.append({
                "id": item.get("call_id", f"call_{uuid.uuid4().hex[:24]}"),
                "type": "function",
                "function": {
                    "name": item.get("name", ""),
                    "arguments": item.get("arguments", "{}"),
                },
            })

    stop_reason = "end_turn"
    if tool_calls:
        stop_reason = "tool_use"
    status = openai_resp.get("status", "completed")
    if status == "incomplete":
        details = openai_resp.get("incomplete_details", {})
        if details.get("reason") == "max_output_tokens":
            stop_reason = "max_tokens"

    usage = openai_resp.get("usage", {})
    prompt_tokens = usage.get("input_tokens", 0)
    completion_tokens = usage.get("output_tokens", 0)

    message = {"role": "assistant"}
    if tool_calls:
        message["content"] = "".join(text_parts) if text_parts else None
        message["tool_calls"] = tool_calls
    else:
        message["content"] = "".join(text_parts)

    return {
        "id": openai_resp.get("id", f"chatcmpl-{uuid.uuid4().hex}"),
        "object": COMPLETION_OBJECT,
        "created": int(time.time()),
        "model": model,
        "choices": [
            {
                "index": 0,
                "message": message,
                "finish_reason": _map_finish_reason_for_chat(stop_reason),
            }
        ],
        "usage": {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        },
    }




class ChatStreamConverter:
    def __init__(self, model):
        self.model = model
        self.id = f"chatcmpl-{uuid.uuid4().hex}"
        self.created = int(time.time())
        self.started = False
        self.finished = False
        self._tool_index_by_call_id = {}
        self._tool_index_by_item_id = {}
        self._next_tool_index = 0
        self._saw_text_delta = False
        self._saw_tool_delta = False

    def _extract_all_from_response_obj(self, resp_obj, events):
        """Extract text and tool calls from a response object's output array.

        Only emits items not already sent via delta streaming, to avoid
        duplicate tool calls or text that cause Cursor to loop.
        """
        if not isinstance(resp_obj, dict):
            return
        output_items = resp_obj.get("output", [])
        if not output_items or not isinstance(output_items, list):
            return

        for item in output_items:
            if not isinstance(item, dict):
                continue
            item_type = item.get("type")

            if item_type == "message" and not self._saw_text_delta:
                text = self._extract_output_text_from_message_item(item)
                if text:
                    self._saw_text_delta = True
                    events.append(self._chunk({"content": text}, finish_reason=None))

            elif item_type == "function_call":
                call_id = item.get("call_id", f"call_{uuid.uuid4().hex[:24]}")
                if call_id in self._tool_index_by_call_id:
                    continue
                self._saw_tool_delta = True
                item_id = item.get("id")
                idx = self._next_tool_index
                self._tool_index_by_call_id[call_id] = idx
                self._next_tool_index += 1
                if item_id:
                    self._tool_index_by_item_id[item_id] = idx
                events.append(self._chunk({
                    "tool_calls": [{
                        "index": idx,
                        "id": call_id,
                        "type": "function",
                        "function": {
                            "name": item.get("name", ""),
                            "arguments": item.get("arguments", "{}"),
                        },
                    }]
                }, finish_reason=None))

    def convert(self, event_type, data):
        events = []

        if not self.started:
            events.append(self._chunk({"role": "assistant"}, finish_reason=None))
            self.started = True

        if event_type in ("response.created", "response.in_progress"):
            resp_obj = data.get("response")
            if isinstance(resp_obj, dict) and resp_obj.get("output"):
                self._extract_all_from_response_obj(resp_obj, events)

        elif event_type == "response.output_text.delta":
            delta_text = data.get("delta", "")
            if delta_text:
                self._saw_text_delta = True
                events.append(self._chunk({"content": delta_text}, finish_reason=None))

        elif event_type == "response.output_item.added":
            item = data.get("item", {})
            if item.get("type") == "function_call":
                self._saw_tool_delta = True
                call_id = item.get("call_id", f"call_{uuid.uuid4().hex[:24]}")
                item_id = item.get("id")
                idx = self._tool_index_by_call_id.get(call_id)
                if idx is None:
                    idx = self._next_tool_index
                    self._tool_index_by_call_id[call_id] = idx
                    self._next_tool_index += 1
                if item_id:
                    self._tool_index_by_item_id[item_id] = idx
                events.append(self._chunk({
                    "tool_calls": [{
                        "index": idx,
                        "id": call_id,
                        "type": "function",
                        "function": {"name": item.get("name", ""), "arguments": ""},
                    }]
                }, finish_reason=None))

        elif event_type == "response.output_item.done":
            item = data.get("item", {})
            item_type = item.get("type")
            if item_type == "message" and not self._saw_text_delta:
                text = self._extract_output_text_from_message_item(item)
                if text:
                    self._saw_text_delta = True
                    events.append(self._chunk({"content": text}, finish_reason=None))
            elif item_type == "function_call":
                call_id = item.get("call_id", f"call_{uuid.uuid4().hex[:24]}")
                if call_id not in self._tool_index_by_call_id:
                    self._saw_tool_delta = True
                    item_id = item.get("id")
                    idx = self._next_tool_index
                    self._tool_index_by_call_id[call_id] = idx
                    self._next_tool_index += 1
                    if item_id:
                        self._tool_index_by_item_id[item_id] = idx
                    events.append(self._chunk({
                        "tool_calls": [{
                            "index": idx,
                            "id": call_id,
                            "type": "function",
                            "function": {
                                "name": item.get("name", ""),
                                "arguments": item.get("arguments", "{}"),
                            },
                        }]
                    }, finish_reason=None))

        elif event_type == "response.function_call_arguments.delta":
            item_id = data.get("item_id")
            delta = data.get("delta", "")
            if delta:
                idx = None
                if item_id:
                    idx = self._tool_index_by_item_id.get(item_id)
                if idx is None and item_id:
                    # Backward compatibility for gateways using call_id as item_id.
                    idx = self._tool_index_by_call_id.get(item_id)
                if idx is not None:
                    events.append(self._chunk({
                        "tool_calls": [{
                            "index": idx,
                            "function": {"arguments": delta},
                        }]
                    }, finish_reason=None))

        elif event_type == "response.completed":
            resp_obj = data.get("response", {})
            if not self._saw_text_delta or not self._saw_tool_delta:
                self._extract_all_from_response_obj(resp_obj, events)

            finish_reason = "tool_calls" if self._tool_index_by_call_id else "stop"
            if resp_obj.get("status") == "incomplete":
                details = resp_obj.get("incomplete_details", {})
                if details.get("reason") == "max_output_tokens":
                    finish_reason = "length"
            events.append(self._chunk({}, finish_reason=finish_reason))
            events.append("data: [DONE]\n\n")
            self.finished = True

        elif event_type == "response.failed":
            resp_obj = data.get("response", {})
            error_obj = resp_obj.get("error", {}) if isinstance(resp_obj, dict) else {}
            error_msg = error_obj.get("message", "Unknown upstream error") if isinstance(error_obj, dict) else str(error_obj)
            self._upstream_error = {"message": error_msg, "type": "upstream_error"}
            if not self._saw_text_delta or not self._saw_tool_delta:
                self._extract_all_from_response_obj(resp_obj, events)
            if not self._saw_text_delta and not self._saw_tool_delta:
                events.append(self._chunk(
                    {"content": f"[Error] {error_msg}"},
                    finish_reason=None,
                ))
            events.append(self._chunk({}, finish_reason="stop"))
            events.append("data: [DONE]\n\n")
            self.finished = True

        elif event_type == "error":
            error_obj = data.get("error", {})
            if isinstance(error_obj, dict):
                error_msg = error_obj.get("message", json.dumps(error_obj, ensure_ascii=False))
            else:
                error_msg = str(error_obj)
            self._upstream_error = {"message": error_msg, "type": "upstream_error"}
            if not self.finished:
                if not self._saw_text_delta and not self._saw_tool_delta:
                    events.append(self._chunk(
                        {"content": f"[Error] {error_msg}"},
                        finish_reason=None,
                    ))
                events.append(self._chunk({}, finish_reason="stop"))
                events.append("data: [DONE]\n\n")
                self.finished = True

        return events

    @staticmethod
    def _extract_output_text_from_message_item(item):
        content = item.get("content", [])
        if not isinstance(content, list):
            return ""
        text_parts = []
        for part in content:
            if isinstance(part, dict) and part.get("type") == "output_text":
                text_parts.append(part.get("text", ""))
        return "".join(text_parts)

    def _chunk(self, delta, finish_reason):
        payload = {
            "id": self.id,
            "object": COMPLETION_CHUNK_OBJECT,
            "created": self.created,
            "model": self.model,
            "choices": [
                {
                    "index": 0,
                    "delta": delta,
                    "finish_reason": finish_reason,
                }
            ],
        }
        return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
