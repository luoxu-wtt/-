﻿import os
from aiohttp import ClientTimeout


UPSTREAM_SESSION_KEY = "upstream_session"
ENABLE_PAYLOAD_SHAPE_LOG = os.getenv("PROXY_ENABLE_PAYLOAD_SHAPE_LOG", "0").lower() in ("1", "true", "yes", "on")
MINIMAL_NODE_LOGGING = os.getenv("PROXY_MINIMAL_NODE_LOGGING", "1").lower() in ("1", "true", "yes", "on")
KEY_NODE_LOG_ALLOWLIST = {
    "request.parse.failed",
    "request.received",
    "upstream.request.sending",
    "upstream.response.headers",
    "upstream.response.error",
    "upstream.response.body",
    "upstream.response.stream.chunk",
    "upstream.response.stream.completed",
    "upstream.response.hint",
    "upstream.response.invalid_protocol",
    "upstream.response.body.fallback_sse_parsed",
    "downstream.response.sent",
    "downstream.stream.prepared",
    "downstream.stream.completed",
    "downstream.stream.simulated",
    "error.gateway.timeout",
    "error.client_disconnected",
    "error.proxy.exception",
}

UPSTREAM_CONN_LIMIT = int(os.getenv("PROXY_UPSTREAM_CONN_LIMIT", "200"))
UPSTREAM_CONN_LIMIT_PER_HOST = int(os.getenv("PROXY_UPSTREAM_CONN_LIMIT_PER_HOST", "100"))
UPSTREAM_TIMEOUT = ClientTimeout(
    total=float(os.getenv("PROXY_UPSTREAM_TIMEOUT_TOTAL", "900")),
    sock_read=float(os.getenv("PROXY_UPSTREAM_TIMEOUT_SOCK_READ", "900")),
)


TARGET_BASE_URL = os.getenv("PROXY_TARGET_BASE_URL", "https://dingxiao-model.dxznjy.com").strip()
TARGET_PATH = os.getenv("PROXY_TARGET_PATH", "/aigrouproup/v1/responses").strip()
TARGET_CHAT_COMPLETIONS_PATH = os.getenv(
    "PROXY_TARGET_CHAT_COMPLETIONS_PATH",
    "/aigrouproup/v1/chat/completions",
).strip()
LOCAL_PORT = int(os.getenv("PROXY_LOCAL_PORT", "8082"))

# Default: responses mode. Legacy: if PROXY_CHAT_COMPLETIONS_PROTOCOL=standard and
# PROXY_PROTOCOL_MODE is unset, treat as chat mode.
_legacy_chat_protocol = os.getenv("PROXY_CHAT_COMPLETIONS_PROTOCOL", "").strip().lower()
_raw_protocol_mode = os.getenv("PROXY_PROTOCOL_MODE", "").strip().lower()
if _raw_protocol_mode:
    PROTOCOL_MODE = _raw_protocol_mode
elif _legacy_chat_protocol == "standard":
    PROTOCOL_MODE = "chat"
else:
    PROTOCOL_MODE = "responses"

CHAT_COMPLETIONS_PROTOCOL = "standard" if PROTOCOL_MODE == "chat" else "responses"
MESSAGES_UPSTREAM_MODE = "developer" if PROTOCOL_MODE == "chat" else "responses"
TARGET_MESSAGES_PATH = TARGET_CHAT_COMPLETIONS_PATH if PROTOCOL_MODE == "chat" else TARGET_PATH

MESSAGES_MODEL_OVERRIDE = os.getenv("PROXY_MESSAGES_MODEL_OVERRIDE", "").strip()
MESSAGES_FORCE_NON_STREAM_RESPONSE = os.getenv(
    "PROXY_MESSAGES_FORCE_NON_STREAM_RESPONSE",
    "0",
).lower() in ("1", "true", "yes", "on")


STREAM_WRITE_BATCH_LIMIT = max(1, int(os.getenv("PROXY_STREAM_WRITE_BATCH_LIMIT", "4")))


ENABLE_REQ_MD_RECORD = os.getenv("PROXY_DEBUG", "0").lower() in ("1", "true", "yes", "on")


def get_advertised_models():
    advertised_raw = os.getenv("PROXY_ADVERTISED_MODELS", "").strip()
    if advertised_raw:
        return [m.strip() for m in advertised_raw.split(",") if m.strip()]
    fallback_model = MESSAGES_MODEL_OVERRIDE or "gpt-5.3-codex"
    return [fallback_model]
